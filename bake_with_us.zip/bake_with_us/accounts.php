<?php
session_start(); // Start the session

// Check if the user is logged in and has the role 'admin'
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "Access Denied. You do not have permission to view this page.";
    exit; // Stop further execution
}

echo "Welcome, Admin! You have access to this page.";

// Include database connection
include "config.php"; 

// Get user ID from session
$user_id = $_SESSION['user_id'] ?? null; // Ensure it exists
$message = "";

// Handle Form Submission Securely
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_account'])) {
    $provider_name = htmlspecialchars($_POST['provider_name']);
    $razorpay_key = htmlspecialchars($_POST['razorpay_key']);
    $razorpay_secret = htmlspecialchars($_POST['razorpay_secret']);

    $stmt = $conn->prepare("INSERT INTO accounts_details (user_id, provider_name, razorpay_key, razorpay_secret) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $provider_name, $razorpay_key, $razorpay_secret);

    if ($stmt->execute()) {
        $message = "<div class='alert success'>Account added successfully!</div>";
    } else {
        $message = "<div class='alert error'>Error: " . $stmt->error . "</div>";
    }
    $stmt->close();
}

// Fetch All Account Details
$sql = "SELECT id, provider_name, razorpay_key, created_at FROM accounts_details WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Accounts</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #181818;
            color: white;
            padding: 20px;
        }
        .navbar {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
        }
        .navbar-brand {
            font-size: 2rem;
            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;
        }
        .nav-link {
            color: #FFD700 !important;
            font-weight: 500;
            transition: all 0.3s ease-in-out;
        }
        .nav-link:hover {
            color: #ffcc33 !important;
            text-shadow: 0px 0px 5px rgba(255, 223, 186, 0.8);
        }
        .containe {
            max-width: 800px;
            
           margin: 100px auto auto  auto;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(255, 255, 255, 0.2);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #FFD700;
        }
        .form-control {
            background: transparent;
            color: white;
            border: 1px solid #FFD700;
        }
        .btn-custom {
            background: #FFD700;
            color: black;
            font-weight: bold;
            border: none;
            padding: 10px;
            border-radius: 5px;
            width: 100%;
        }
        .btn-custom:hover {
            background: #ffcc33;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            color: white;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #FFD700;
        }
        th {
            background: #FFD700;
            color: black;
        }
        .alert {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
        }
        .alert.success {
            background: #4CAF50;
            color: white;
        }
        .alert.error {
            background: #FF5733;
            color: white;
        }
        .btn-delete {
            background: red;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-delete:hover {
            background: darkred;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">Bake With Us 🎂</a>
        <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="admin.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="add_cake.php">Manage Cakes</a></li>
                <li class="nav-item"><a class="nav-link" href="orders.php">Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="accounts.php">Payment Details</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="containe">
    <h2><i class="fas fa-wallet"></i> Manage Payment Accounts</h2>

    <?php echo $message; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label"><i class="fas fa-building"></i> Provider Name</label>
            <input type="text" name="provider_name" class="form-control" required>
        </div>
        
        <div class="mb-3">
            <label class="form-label"><i class="fas fa-key"></i> Razorpay Key</label>
            <input type="text" name="razorpay_key" class="form-control" required>
        </div>
        
        <div class="mb-3">
            <label class="form-label"><i class="fas fa-lock"></i> Razorpay Secret</label>
            <input type="password" name="razorpay_secret" class="form-control" required>
        </div>
        
        <button type="submit" name="add_account" class="btn btn-custom"><i class="fas fa-plus"></i> Add Account</button>
    </form>

    <h2><i class="fas fa-list"></i> Your Accounts</h2>
    <table class="table">
        <tr>
            <th>ID</th>
            <th>Provider Name</th>
            <th>Razorpay Key</th>
            <th>Created At</th>
            <th>Actions</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>".$row["id"]."</td>
                        <td>".$row["provider_name"]."</td>
                        <td>".$row["razorpay_key"]."</td>
                        <td>".$row["created_at"]."</td>
                        <td>
                            <form method='POST' action='delete.php' style='display:inline;'>
                                <input type='hidden' name='id' value='".$row["id"]."'>
                                <button type='submit' class='btn-delete' onclick='return confirm(\"Are you sure you want to delete this account?\")'>
                                    <i class='fas fa-trash'></i> Delete
                                </button>
                            </form>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5' style='text-align:center;'>No accounts found.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
