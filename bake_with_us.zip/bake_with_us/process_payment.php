<?php
// process_payment.php
session_start();
include "config.php"; // Include database connection

// Verify the payment details from Razorpay
if (isset($_POST['razorpay_payment_id']) && $_POST['razorpay_payment_id'] != '') {
    $payment_id = $_POST['razorpay_payment_id'];
    $amount = floatval($_POST['amount']);
    $primary_cake_id = intval($_POST['primary_cake_id']);
    $merchant_order_id = $_POST['merchant_order_id'];

    // Get current date time
    $payment_date = date('Y-m-d H:i:s');

    // Get the user ID from session
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['payment_error'] = "User session expired. Please log in again.";
        header("Location: login.php");
        exit;
    }
    
    $user_id = $_SESSION['user_id'];

    try {
        // Start a transaction for data consistency
        $conn->begin_transaction();

        // 1. Create an order record
        $orderSql = "INSERT INTO orders (order_id, user_id, total_amount, payment_status, created_at) 
                    VALUES (?, ?, ?, 'completed', ?)";

        $orderStmt = $conn->prepare($orderSql);
        $orderStmt->bind_param("sids", $merchant_order_id, $user_id, $amount, $payment_date);

        if (!$orderStmt->execute()) {
            throw new Exception("Failed to create order record: " . $conn->error);
        }

        // 2. Store payment information
        $paymentSql = "INSERT INTO payments (payment_id, order_id, user_id, amount, payment_method, payment_date, payment_status) 
                      VALUES (?, ?, ?, ?, 'razorpay', ?, 'completed')";

        $paymentStmt = $conn->prepare($paymentSql);
        $paymentStmt->bind_param("ssids", $payment_id, $merchant_order_id, $user_id, $amount, $payment_date);

        if (!$paymentStmt->execute()) {
            throw new Exception("Failed to create payment record: " . $conn->error);
        }

        // 3. Update cart items to mark them as ordered
        $updateCartSql = "UPDATE cart SET 
                         order_status = 'paid',
                         order_id = ?,
                         updated_at = NOW()
                         WHERE order_status = 'pending' AND user_id = ?";

        $updateStmt = $conn->prepare($updateCartSql);
        $updateStmt->bind_param("si", $merchant_order_id, $user_id);

        if (!$updateStmt->execute()) {
            throw new Exception("Failed to update cart items: " . $conn->error);
        }

        // 4. Create order items from the cart items
        $createOrderItemsSql = "INSERT INTO order_items 
                              (order_id, cake_id, quantity, price, toppings_json, message_text, special_design)
                              SELECT ?, cake_id, quantity, item_total, toppings_json, message_text, special_design
                              FROM cart 
                              WHERE order_id = ? AND user_id = ?";

        $orderItemsStmt = $conn->prepare($createOrderItemsSql);
        $orderItemsStmt->bind_param("ssi", $merchant_order_id, $merchant_order_id, $user_id);
        $orderItemsStmt->execute();

        // Commit the transaction
        $conn->commit();

        // Set success message in session
        $_SESSION['payment_success'] = true;
        $_SESSION['order_id'] = $merchant_order_id;

        // Redirect to order confirmation page
        header("Location: order_confirmation.php");
        exit;

    } catch (Exception $e) {
        // Rollback the transaction if any query fails
        $conn->rollback();

        // Log the error
        error_log("Payment processing error: " . $e->getMessage());

        // Payment was successful but we couldn't record it
        $_SESSION['payment_error'] = "Payment was successful but we couldn't complete the order processing. Please contact support with this reference: " . $payment_id;
        header("Location: cart.php");
        exit;
    }
} else {
    // Payment failed or was cancelled
    $_SESSION['payment_error'] = "Payment failed or was cancelled. Please try again.";
    header("Location: cart.php");
    exit;
}
?>
