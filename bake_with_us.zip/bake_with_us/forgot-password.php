<?php  
session_start();
include "config.php"; // Database connection

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Set correct timezone
date_default_timezone_set('UTC'); // Change to your server's timezone if needed

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);

    // Check if email exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($user_id);
    $stmt->fetch();

    if ($user_id) { // Check if user exists
        // Generate a secure token
        $token = bin2hex(random_bytes(50));
        $created_at = date("Y-m-d H:i:s");
        $expires_at = date("Y-m-d H:i:s", strtotime("+10 minutes"));

        // Store the token in the database
        $stmt = $conn->prepare("INSERT INTO password_reset_tokens (email, token, created_at, expires_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $email, $token, $created_at, $expires_at);
        $stmt->execute();

        // Send password reset email
        $resetLink = "http://localhost/bake_with_us/reset-password.php?token=$token";

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'shahvivaan308@gmail.com';
            $mail->Password = 'ijxo jxmd cqnb mvck'; // Use App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            $mail->SMTPDebug = 2; // Enable debugging
            $mail->Debugoutput = 'html';

            $mail->setFrom('shahvivaan308@gmail.com', 'Bake With Us');
            $mail->addAddress($email);
            $mail->Subject = "Password Reset Request";
            $mail->Body = "Click the following link to reset your password (Valid for 10 minutes):? $resetLink";
            $mail->send();

            $_SESSION['success'] = "A password reset link has been sent to your email.";
        } catch (Exception $e) {
            $_SESSION['error'] = "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $_SESSION['error'] = "No account found with this email.";
    }
    header("Location: forgot-password.php");
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Forgot Password</h2>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php elseif (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <form action="forgot-password.php" method="POST">
        <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
        <button type="submit" class="btn btn-primary mt-2">Send Reset Link</button>
       
    </form>
</div>
</body>
</html>
