<?php
session_start();
include "config.php"; // Database connection

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $account_id = intval($_POST['id']);
    $user_id = $_SESSION['user_id'];

    // Ensure user can only delete their own account details
    $stmt = $conn->prepare("DELETE FROM accounts_details WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $account_id, $user_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "<div class='alert success'>Account deleted successfully!</div>";
    } else {
        $_SESSION['message'] = "<div class='alert error'>Error: " . $stmt->error . "</div>";
    }
    $stmt->close();
    $conn->close();

    header("Location: accounts.php");
    exit();
}
?>

