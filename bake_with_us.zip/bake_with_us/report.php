<?php
session_start();
include "config.php"; // Database connection

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Initialize date filters
$start_date = $_POST['start_date'] ?? null;
$end_date = $_POST['end_date'] ?? null;

// Function to format currency
function formatCurrency($amount) {
    return '₹' . number_format($amount, 2);
}

// Function to build date filter clause
function buildDateFilter($column) {
    global $start_date, $end_date;
    
    $clause = '';
    if($start_date && $end_date) {
        $clause = " AND $column BETWEEN '$start_date' AND '$end_date 23:59:59'";
    }
    return $clause;
}
$totalUsersQuery = "SELECT COUNT(*) AS total FROM users";
$result = $conn->query($totalUsersQuery);
$totalUsers = $result->fetch_assoc()['total'] ?? 0;

$newUsersMonthQuery = "SELECT COUNT(*) AS total FROM users 
                      WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
$result = $conn->query($newUsersMonthQuery);
$newUsersMonth = $result->fetch_assoc()['total'] ?? 0;

$newUsersWeekQuery = "SELECT COUNT(*) AS total FROM users 
                     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
$result = $conn->query($newUsersWeekQuery);
$newUsersWeek = $result->fetch_assoc()['total'] ?? 0;

// Order Metrics
$totalOrdersQuery = "SELECT COUNT(*) AS total FROM orders 
                    WHERE payment_status = 'completed'";
$totalOrdersQuery .= buildDateFilter('created_at');
$result = $conn->query($totalOrdersQuery);
$totalOrders = $result->fetch_assoc()['total'] ?? 0;

// Product Metrics
$totalProductsQuery = "SELECT COUNT(*) AS total FROM cakes";
$result = $conn->query($totalProductsQuery);
$totalProducts = $result->fetch_assoc()['total'] ?? 0;
// Calculate all metrics before HTML output
// --------------------------------------------------
// Total Revenue
$query = "SELECT SUM(total_amount) AS value FROM orders 
         WHERE payment_status = 'completed'";
$query .= buildDateFilter('created_at');
$result = $conn->query($query);
$revenue = $result->fetch_assoc()['value'] ?? 0;

// Average Order Value
$query = "SELECT AVG(total_amount) AS value FROM orders 
         WHERE payment_status = 'completed'";
$query .= buildDateFilter('created_at');
$result = $conn->query($query);
$aov = $result->fetch_assoc()['value'] ?? 0;

// Conversion Rate
$queryCarts = "SELECT COUNT(*) AS carts FROM cart";
$queryOrders = "SELECT COUNT(DISTINCT order_id) AS orders FROM cart 
               WHERE order_id IS NOT NULL";
$result = $conn->query($queryCarts);
$totalCarts = $result->fetch_assoc()['carts'] ?? 0;
$result = $conn->query($queryOrders);
$completedOrders = $result->fetch_assoc()['orders'] ?? 0;
$conversionRate = ($totalCarts > 0) ? ($completedOrders / $totalCarts) * 100 : 0;

// Revenue by Cake Type
$revenueByTypeQuery = "SELECT c.type, COUNT(*) AS orders, SUM(oi.quantity * oi.price) AS revenue
                     FROM order_items oi
                     JOIN cakes c ON oi.cake_id = c.id
                     JOIN orders o ON oi.order_id = o.order_id
                     WHERE o.payment_status = 'completed'";
$revenueByTypeQuery .= buildDateFilter('o.created_at');
$revenueByTypeQuery .= " GROUP BY c.type ORDER BY revenue DESC";
$revenueByTypeResult = $conn->query($revenueByTypeQuery);

// Monthly Revenue Trend
$monthlyTrendQuery = "SELECT 
                     DATE_FORMAT(created_at, '%Y-%m') AS month,
                     COUNT(*) AS orders,
                     SUM(total_amount) AS revenue
                   FROM orders
                   WHERE payment_status = 'completed'
                   GROUP BY month
                   ORDER BY month DESC";
$monthlyTrendResult = $conn->query($monthlyTrendQuery);
$prevRevenue = null;

// Payment Methods
$paymentMethodQuery = "SELECT 
                      payment_method,
                      COUNT(*) AS transactions,
                      SUM(amount) AS total
                    FROM payments
                    WHERE payment_status = 'completed'";
$paymentMethodQuery .= buildDateFilter('payment_date');
$paymentMethodQuery .= " GROUP BY payment_method";
$paymentMethodResult = $conn->query($paymentMethodQuery);
$totalTransactions = 0;
$totalAmount = 0;

// Calculate payment method totals
if ($paymentMethodResult->num_rows > 0) {
    $paymentRows = $paymentMethodResult->fetch_all(MYSQLI_ASSOC);
    foreach($paymentRows as $row) {
        $totalTransactions += $row['transactions'];
        $totalAmount += $row['total'];
    }
}
// 1. Repeat Customer Rate
$repeatCustomerQuery = "SELECT 
    COUNT(*) AS total_customers,
    SUM(orders_count > 1) AS repeat_customers
FROM (
    SELECT user_id, COUNT(*) AS orders_count
    FROM orders
    WHERE payment_status = 'completed'
    GROUP BY user_id
) AS customer_orders";

$result = $conn->query($repeatCustomerQuery);
$row = $result->fetch_assoc();
$repeatRate = ($row['total_customers'] > 0) 
    ? ($row['repeat_customers'] / $row['total_customers']) * 100 
    : 0;

// 2. Top Selling Products by Quantity
$topProductsQuery = "SELECT 
    c.name,
    SUM(oi.quantity) AS total_quantity,
    SUM(oi.quantity * oi.price) AS total_revenue
FROM order_items oi
JOIN cakes c ON oi.cake_id = c.id
GROUP BY c.name
ORDER BY total_quantity DESC
LIMIT 5";
$topProductsResult = $conn->query($topProductsQuery);

// 3. Cart Abandonment Rate
$abandonedCartsQuery = "SELECT COUNT(*) AS abandoned FROM cart 
                       WHERE order_status = 'pending'";
$result = $conn->query($abandonedCartsQuery);
$abandonedCarts = $result->fetch_assoc()['abandoned'] ?? 0;
$cartAbandonmentRate = ($totalCarts > 0)
    ? ($abandonedCarts / $totalCarts) * 100
    : 0;

// 4. Average Product Rating
$avgRatingQuery = "SELECT 
    c.name,
    AVG(r.rating) AS avg_rating,
    COUNT(r.id) AS review_count
FROM reviews r
JOIN cakes c ON r.cake_id = c.id
GROUP BY c.name
ORDER BY avg_rating DESC";
$avgRatingResult = $conn->query($avgRatingQuery);

// 5. Active Customers (30 Days)
$activeCustomersQuery = "SELECT COUNT(DISTINCT user_id) AS active_users
                        FROM orders
                        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                        AND payment_status = 'completed'";
$result = $conn->query($activeCustomersQuery);
$activeCustomers = $result->fetch_assoc()['active_users'] ?? 0;
?>
<!DOCTYPE html>
<html>
<head>
   
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
       

        body {
            font-family: 'Poppins', sans-serif; 
            color: #fff; 
            background-color: #333;
            color:rgb(0, 0, 0);
            
       
        }
        .navbar { 
            
            background: rgba(0, 0, 0, 0.7); 
            backdrop-filter: blur(10px); 
            
        }
        .navbar-brand {     
            font-family: 'Montserrat', sans-serif;
            font-size: 2rem; 
            color: #FFD700 !important; 
        
        }
        .nav-link { 
            color: #FFD700 !important; 
            font-weight: 500; 
            transition: all 0.3s ease-in-out; 
        }
        .nav-link:hover { 
            color: #ffcc33 !important; 
            text-shadow: 0px 0px 5px rgba(255, 223, 186, 0.8); 
        }

        .container1 {
            max-width: 1400px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            color: #3498db;
            margin-bottom: 2rem;
            font-size: 2.5rem;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .date-filter {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .date-filter input, .date-filter button {
            padding: 0.8rem 1.2rem;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .date-filter button {
            background: #3498db;
            color: white;
            border: none;
            cursor: pointer;
            text-transform: uppercase;
            font-weight: 500;
        }

        .date-filter button:hover {
            background: #2980b9;
        }

        .metric-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .metric-box {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            text-align: center;
        }

        .metric-box h3 {
            color: #7f8c8d;
            font-size: 1rem;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .metric-box p {
            font-size: 1.8rem;
            font-weight: 600;
            color: #2c3e50;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin: 1.5rem 0;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 1px 10px rgba(0,0,0,0.05);
        }

        .report-table th,
        .report-table td {
            padding: 1rem 1.5rem;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }

        .report-table th {
            background: #3498db;
            color: white;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }

        .report-table tr:hover {
            background-color: #f8f9fa;
        }

        .report-table tr:last-child td {
            border-bottom: none;
        }

        .section-header {
            font-size: 1.3rem;
            font-weight: 600;
            color:rgb(30, 0, 255);
            margin: 2rem 0 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #3498db;
            display: inline-block;
        }

        .positive {
            color: #27ae60;
            font-weight: 500;
        }

        .negative {
            color: #e74c3c;
            font-weight: 500;
        }

        .percentage {
            font-size: 0.9rem;
            color: #7f8c8d;
        }

        @media (max-width: 768px) {
            body {
                padding: 1rem;
            }
            
            .report-table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
        }
       
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">Bake With Us 🎂</a>
        <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="admin.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="add_cake.php">Manage Cakes</a></li>
                <li class="nav-item"><a class="nav-link" href="orders.php">Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="report.php">Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container1">
        <h1>BakeWithUs Analytics Dashboard</h1>
        
        <!-- Date Filter Form -->
        <form class="date-filter" method="POST">
            <input type="date" name="start_date" value="<?= $start_date ?>">
            <input type="date" name="end_date" value="<?= $end_date ?>">
            <button type="submit">Apply Filter</button>
            <button type="button" onclick="window.location.href='?'">Clear</button>
        </form>

        <div class="metric-grid">
            <!-- User Metrics -->
            <div class="metric-box">
                <h3>Total Users</h3>
                <p><?= number_format($totalUsers) ?></p>
            </div>
            
            <div class="metric-box">
                <h3>New Users (30 Days)</h3>
                <p>+<?= number_format($newUsersMonth) ?></p>
            </div>

            <!-- Order Metrics -->
            <div class="metric-box">
                <h3>Total Orders</h3>
                <p><?= number_format($totalOrders) ?></p>
            </div>
            
            <div class="metric-box">
                <h3>Total Products</h3>
                <p><?= number_format($totalProducts) ?></p>
            </div>

            <!-- Existing Financial Metrics -->
            <div class="metric-box">
                <h3>Total Revenue</h3>
                <p><?= formatCurrency($revenue) ?></p>
            </div>
            
            <div class="metric-box">
                <h3>Avg. Order Value</h3>
                <p><?= formatCurrency($aov) ?></p>
            </div>
            
            <div class="metric-box">
                <h3>Conversion Rate</h3>
                <p><?= number_format($conversionRate, 1) ?>%</p>
            </div>
    
        <div class="metric-box">
                <h3>Repeat Customers</h3>
                <p><?= number_format($repeatRate, 1) ?>%</p>
            </div>
            
            <div class="metric-box">
                <h3>Active Customers</h3>
                <p><?= number_format($activeCustomers) ?></p>
            </div>
            
            <div class="metric-box">
                <h3>Cart Abandonment</h3>
                <p><?= number_format($cartAbandonmentRate, 1) ?>%</p>
            </div>
        </div>

        <!-- New User Acquisition Chart -->
        <div class="section-header">User Acquisition</div>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Period</th>
                    <th>New Users</th>
                    <th>Growth Rate</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $userGrowthQuery = "SELECT 
                    DATE_FORMAT(created_at, '%Y-%m') AS month,
                    COUNT(*) AS users
                    FROM users
                    GROUP BY month
                    ORDER BY month DESC
                    LIMIT 6";
                
                $result = $conn->query($userGrowthQuery);
                $prevUsers = null;
                
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $growth = $prevUsers ? 
                            (($row['users'] - $prevUsers) / $prevUsers) * 100 : 
                            null;
                ?>
                <tr>
                    <td><?= $row['month'] ?></td>
                    <td><?= $row['users'] ?></td>
                    <td>
                        <?php if($growth !== null): 
                            $class = ($growth >= 0) ? 'positive' : 'negative';
                            $arrow = ($growth >= 0) ? '↑' : '↓';
                        ?>
                        <span class="<?= $class ?>">
                            <?= $arrow ?> <?= number_format(abs($growth), 1) ?>%
                        </span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
                <?php
                        $prevUsers = $row['users'];
                    }
                }
                ?>
            </tbody>
        </table>

        <!-- ... [Keep existing tables for revenue, trends, payments] ... -->

        <!-- Order Activity Table -->
        <div class="section-header">Recent Orders</div>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
                
            </thead>
            <tbody>
            
                <?php
                $recentOrdersQuery = "SELECT 
                    order_id, 
                    total_amount, 
                    created_at,
                    delivery_status
                    FROM orders
                    ORDER BY created_at DESC
                    LIMIT 10";
                
                $result = $conn->query($recentOrdersQuery);
                
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $statusClass = strtolower($row['delivery_status']) === 'completed' 
                            ? 'positive' 
                            : 'negative';
                ?>
                <tr>
                    <td>#<?= $row['order_id'] ?></td>
                    <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                    <td><?= formatCurrency($row['total_amount']) ?></td>
                    <td>
                        <span class="<?= $statusClass ?>">
                            <?= ucfirst($row['delivery_status']) ?>
                        </span>
                    </td>
                </tr>
                <?php
                    }
                } else {
                    echo "<tr><td colspan='4'>No recent orders found</td></tr>";
                }
                ?>
            </tbody>
        </table>
                 <div class="section-header">Revenue by Cake Type</div>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Cake Type</th>
                    <th>Orders</th>
                    <th>Revenue</th>
                    <th>Market Share</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($revenueByTypeResult->num_rows > 0): ?>
                    <?php while($row = $revenueByTypeResult->fetch_assoc()): 
                        $marketShare = ($revenue > 0) ? ($row['revenue'] / $revenue) * 100 : 0;
                    ?>
                    <tr>
                        <td><?= $row['type'] ?></td>
                        <td><?= $row['orders'] ?></td>
                        <td><?= formatCurrency($row['revenue']) ?></td>
                        <td><span class="percentage"><?= number_format($marketShare, 1) ?>%</span></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">No data available</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

       
        <div class="section-header">Top Selling Products</div>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity Sold</th>
                    <th>Revenue</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($topProductsResult->num_rows > 0): ?>
                    <?php while($row = $topProductsResult->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['name'] ?></td>
                        <td><?= $row['total_quantity'] ?></td>
                        <td><?= formatCurrency($row['total_revenue']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="3">No sales data available</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

         <!-- Monthly Revenue Trend Table -->
         <div class="section-header">Monthly Revenue Trend</div>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Month</th>
                    <th>Orders</th>
                    <th>Revenue</th>
                    <th>MoM Growth</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($monthlyTrendResult->num_rows > 0): ?>
                    <?php while($row = $monthlyTrendResult->fetch_assoc()): 
                        $growth = $prevRevenue ? (($row['revenue'] - $prevRevenue) / $prevRevenue) * 100 : null;
                    ?>
                    <tr>
                        <td><?= $row['month'] ?></td>
                        <td><?= $row['orders'] ?></td>
                        <td><?= formatCurrency($row['revenue']) ?></td>
                        <td>
                            <?php if($growth !== null): 
                                $class = ($growth >= 0) ? 'positive' : 'negative';
                                $arrow = ($growth >= 0) ? '↑' : '↓';
                            ?>
                            <span class="<?= $class ?>">
                                <?= $arrow ?> <?= number_format(abs($growth), 1) ?>%
                            </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php 
                        $prevRevenue = $row['revenue'];
                        endwhile; 
                    ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">No data available</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Payment Method Distribution Table -->
        <div class="section-header">Payment Methods</div>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Method</th>
                    <th>Transactions</th>
                    <th>Total Amount</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($paymentRows)): ?>
                    <?php foreach($paymentRows as $row): 
                        $percentage = ($totalTransactions > 0) ? ($row['transactions'] / $totalTransactions) * 100 : 0;
                    ?>
                    <tr>
                        <td><?= $row['payment_method'] ?></td>
                        <td><?= $row['transactions'] ?></td>
                        <td><?= formatCurrency($row['total']) ?></td>
                        <td><span class="percentage"><?= number_format($percentage, 1) ?>%</span></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">No payment data available</td>
                    </tr>
                <?php endif; ?>
            
            </tbody>
        </table>

        <div class="section-header">Product Ratings</div>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Average Rating</th>
                    <th>Reviews</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($avgRatingResult->num_rows > 0): ?>
                    <?php while($row = $avgRatingResult->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['name'] ?></td>
                        <td><?= number_format($row['avg_rating'], 1) ?>/5</td>
                        <td><?= $row['review_count'] ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="3">No reviews available</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
$conn->close();
?>