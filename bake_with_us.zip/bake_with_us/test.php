

<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection
require_once 'config.php';

// Initialize response array
$response = [
    'success' => false,
    'message' => '',
    'cart_count' => 0
];

// Check if it's an AJAX request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_cart') {
    try {
        // Get form data
        $cake_id = isset($_POST['cake_id']) ? intval($_POST['cake_id']) : 0;
        $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
        $message_text = isset($_POST['message_text']) ? trim($_POST['message_text']) : '';
        $special_design = isset($_POST['special_design']) ? trim($_POST['special_design']) : '';
        $toppings = isset($_POST['toppings']) ? json_encode($_POST['toppings']) : '[]'; // Store directly

        // Validate inputs
        if ($cake_id <= 0) {
            throw new Exception("Invalid cake selection");
        }
        if ($quantity <= 0) {
            $quantity = 1;
        }

        // Fetch cake details from database
        $stmt = $conn->prepare("SELECT id, name, price, image FROM cakes WHERE id = ?");
        $stmt->bind_param("i", $cake_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            throw new Exception("Cake not found");
        }
        $cake = $result->fetch_assoc();
        $base_price = $cake['price'];

        // Directly calculate total price (without fetching extra costs)
        $item_total = ($base_price * $quantity);

        // Insert into database if user is logged in
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
            $stmt = $conn->prepare("INSERT INTO cart (user_id, cake_id, quantity, message_text, special_design, toppings_json, base_price, item_total, created_at, updated_at) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
            $stmt->bind_param("iiisssdd", $user_id, $cake_id, $quantity, $message_text, $special_design, $toppings, $base_price, $item_total);
            
            if (!$stmt->execute()) {
                throw new Exception("Database Error: " . $stmt->error);
            }
        }

        // Add to session cart
        $cart_item_id = uniqid('cart_');
        $_SESSION['cart'][$cart_item_id] = [
            'cake_id' => $cake_id,
            'cake_name' => $cake['name'],
            'cake_image' => $cake['image'],
            'quantity' => $quantity,
            'message_text' => $message_text,
            'special_design' => $special_design,
            'toppings' => json_decode($toppings, true), // Convert back for session
            'base_price' => $base_price,
            'item_total' => $item_total,
            'added_at' => date('Y-m-d H:i:s')
        ];

        // Set success response
        $response['success'] = true;
        $response['message'] = 'Item added to cart successfully';
        $response['cart_count'] = count($_SESSION['cart']);
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
    }
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
