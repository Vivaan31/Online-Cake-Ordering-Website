<?php
session_start();
include "config.php"; // Database connection

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Validate CSRF token
if ($_SERVER["REQUEST_METHOD"] === "POST") {
   
    // Ensure review_id is provided
    if (!isset($_POST['review_id']) || empty($_POST['review_id'])) {
        header("Location: user.php?error=Invalid review ID");
        exit();
    }

    $review_id = intval($_POST['review_id']);

    // Prepare SQL to delete the review securely
    $query = "DELETE FROM reviews WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $review_id, $user_id);

    if ($stmt->execute()) {
        header("Location: user.php?success=Review deleted successfully");
        exit();
    } else {
        header("Location: user.php?error=Failed to delete review");
        exit();
    }
} else {
    header("Location: user.php");
    exit();
}
?>
