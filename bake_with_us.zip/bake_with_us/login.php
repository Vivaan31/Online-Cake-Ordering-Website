<?php
session_start();
include "config.php"; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Fetch user data from the database
    $stmt = $conn->prepare("SELECT id, username, password_hash, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $username, $hashed_password, $role);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashed_password)) {
            $_SESSION["user_id"] = $id;
            $_SESSION["username"] = $username;
            $_SESSION["email"] = $email;
            $_SESSION["role"] = $role;

            // Redirect based on role
            if ($role === 'admin') {
                header("Location: admin.php");
            } else {
                header("Location: cakes.php");
            }
            exit();
        } else {
            $_SESSION['error'] = "Invalid email or password!";
        }
    } else {
        $_SESSION['error'] = "No account found with this email!";
    }
    
    $stmt->close();
    header("Location: login.php"); // Redirect to login page to show the message
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bake With Us - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
    body {
    
    background: url('images/bg7.jpg') no-repeat center center fixed;
    background-size:100%; /* Ensures the image covers the entire page */
    min-height: 100vh;
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding-top: 70px;
    }

    .login-container {
        width: 100%;
        max-width: 420px;
        margin: 20px auto;
        padding: 2.5rem;
        position: relative;
    align-items: center;
        background: rgb(0, 0, 0);
        backdrop-filter: blur(15px) saturate(180%);
        border: 3px solid rgb(255, 255, 255);
        border-radius: 20px;
        padding: 40px;
        width: 420px;
        transform: translateY(0);
        animation: float 3s ease-in-out infinite;
    }

    @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }

    .login-container h1 {
        font-size: 3.5rem;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        position: relative;
        margin-bottom: 30px;
    }

    .login-container h1::after {
        content: '';
        position: absolute;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        width: 60px;
        height: 3px;
        background: #FFD700;
        border-radius: 2px;
    }
    .form-control::placeholder {
    color: rgb(255, 255, 255); /* Gold color */
    opacity: 1; /* Ensures visibility in some browsers */
}
    .form-control {
        background: rgba(255, 255, 255, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #fff;
        padding: 15px 20px 15px 45px;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        background: rgba(255, 255, 255, 0.3);
        border-color: #FFD700;
        box-shadow: 0 0 15px rgba(255, 215, 0, 0.2);
    }

    .input-icon {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: rgb(255, 255, 255);
        z-index: 2;
    }
    .form-group {
        margin-bottom: 1.5rem;
    }

    .btn-login {
        background: linear-gradient(45deg, #FFD700, #ffb400);
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
        margin-top: 1rem;
        width: 100%;
    }

    .btn-login:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4);
    }

    .btn-login::after {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: rgba(255, 255, 255, 0.1);
        transform: rotate(45deg);
        transition: all 0.5s ease;
    }

    .btn-login:hover::after {
        left: 50%;
        top: 50%;
    }

    .register-link {
        margin-top: 25px;
        color: rgb(255, 255, 255);
        font-size: medium;
        font-weight: 600;
    }

    .register-link a {
        position: relative;
        padding-bottom: 2px;
        color: rgb(0, 29, 192);
    }

    .register-link a::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 0;
        height: 1px;
        background: #FFD700;
        transition: width 0.3s ease;
    }

    .register-link a:hover::after {
        width: 100%;
       
    }

    .password-toggle {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        color: rgba(255, 255, 255, 0.7);
    }
    .links-container {
        text-align: center;
        margin-top: 1.5rem;
    }

    .forgot-password-link {
        margin-top: 1rem;
    }
    .alert-container .alert {
        backdrop-filter: blur(10px);
        background: rgba(255, 75, 75, 0.15);
        border: 1px solid rgba(255, 150, 150, 0.2);
        color: #fff;
        position: fixed;
        top: 80px;
        left: 50%;
        transform: translateX(-50%);
        width: 90%;
        max-width: 420px;
        z-index: 1000;
    }
    .navbar-brand {
        font-size: 3rem !important; /* Increased from 2rem */
        font-family: 'Great Vibes', cursive;
        color: #FFD700 !important;
        transition: all 0.3s ease;
    }

    .navbar-brand:hover {
        transform: scale(1.05);
        text-shadow: 0 0 15px rgba(255, 215, 0, 0.4);
    }
    .login-container h1 {
        font-family: 'Great Vibes', cursive;
        text-align: center;
        color: white;
        font-size: 4rem; /* Increased from 3.5rem */
        width: 100%;
        letter-spacing: 2px;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .navbar-brand {
            font-size: 2.5rem !important;
        }
        
        .login-container h1 {
            font-size: 3.5rem;
        }
    }

    @media (max-width: 576px) {
        .navbar-brand {
            font-size: 2rem !important;
        }
        
        .login-container h1 {
            font-size: 3rem;
        }
    }

    
</style>
</head>
<body>


  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg fixed-top  shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="home.php">Bake With Us 🎂</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav me-3">
            </ul>
            <!-- Login and Register Buttons -->
            <div>
                <a href="login.php" class="btn btn-primary me-2">Login</a>
                <a href="register.php" class="btn btn-primary">Register</a>
            </div>
        </div>
    </div>
</nav>

    <div class="alert-container">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
    </div>
   
    <div class="login-container">
    <h1>Login</h1>
    <form action="login.php" method="POST">
        <div class="form-group position-relative">
            <i class="fas fa-envelope input-icon"></i>
            <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
        </div>
        <div class="form-group position-relative">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" required>
            <i class="password-toggle fas fa-eye" onclick="togglePassword()"></i>
        </div>
        <button type="submit" class="btn btn-login">Login</button>
    </form>
    <div class="links-container">
        <div class="register-link">
            Don't have an account ? <a href="register.php">Register Here</a>
        </div>
        <div class="register-link">
            Forgot your password ? <a href="forgot-password.php">Forgot Password?</a>
        </div>
    </div>
</div>

</body>
</html>

<script>
    function togglePassword() {
        const passwordField = document.getElementById('password');
        const toggleIcon = document.querySelector('.password-toggle');
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }

    // Add input focus effects
    document.querySelectorAll('.form-control').forEach(input => {
        input.addEventListener('focus', () => {
            input.previousElementSibling.style.color = '#FFD700';
        });
        input.addEventListener('blur', () => {
            input.previousElementSibling.style.color = 'rgba(255, 255, 255, 0.7)';
        });
    });
</script>