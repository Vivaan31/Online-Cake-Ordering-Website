<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bake With Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        :root {
            --gold: #FFD700;
            --rose: #FF6B6B;
            --cream: #FFF3E4;
            --dark: #2A2A2A;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--cream);
            color: var(--dark);
            overflow-x: hidden;
        }

        /* Navbar */
        .navbar {
            background: rgba(0, 0, 0, 0.95) !important;
            backdrop-filter: blur(15px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 3rem;
            font-family: 'Great Vibes', cursive;
            color: var(--rose) !important;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .nav-link {
            color: var(--dark) !important;
            font-weight: 500;
            position: relative;
            margin: 0 1rem;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--rose);
            transition: width 0.3s ease;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        /* Hero Section */
        .hero {
    position: relative;
    height: 100vh;
    background: linear-gradient(45deg, rgba(255, 107, 107, 0.1), rgba(255, 215, 0, 0.1)),
                url('images/home2.jpg') center/cover no-repeat;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    overflow: hidden;
    background-attachment: fixed; /* Creates parallax effect */

}
.hero::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background:fixed;
  
}


        .hero-text {
            position: relative;
            z-index: 2;
            max-width: 800px;
            animation: fadeInUp 1s cubic-bezier(0.23, 1, 0.32, 1);
        }

        .hero-text h1 {
            font-size: 3.6rem;
            font-family:Georgia, 'Times New Roman', Times, serif;
            color: rgb(0, 0, 0);
            text-shadow: 5px 5px 15px rgb(255, 255, 255);
            margin-bottom: 2rem;
            font-weight: 1000;
        }


.hero-text p {
    font-size: 1.8rem;
    color: white; /* Change to white for better contrast */
    text-shadow: 3px 3px 8px rgba(0, 0, 0, 0.7); /* Stronger shadow for better readability */
    margin-bottom: 3rem;
    font-weight: 1000;
    line-height: 1.7;
}


        /* Order Button */
        .btn-order {
            background:black;
            color: white;
            padding: 1.2rem 3rem;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1.2rem;
            letter-spacing: 1px;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            border: none;
        }

        .btn-order::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                120deg,
                transparent,
                rgb(0, 0, 0),
                transparent
            );
            transition: 0.6s;
        }

        .btn-order:hover::before {
            left: 100%;
        }

        .btn-order:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgb(0, 0, 0);
        }

        /* Cake Cards */
        .cakes {
            padding: 8rem 2rem;
            background: black;
        }

        .cake-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 30px rgb(0, 0, 0);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
            position: relative;
        }

        .cake-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, transparent, rgb(0, 0, 0));
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .cake-card:hover {
            transform: translateY(-10px);
        }

        .cake-card:hover::before {
            opacity: 1;
        }

        .cake-card img {
            width: 100%;
            height: 300px;
            object-fit: cover;
            transition: transform 0.4s ease;
        }

        .cake-card:hover img {
            transform: scale(1.05);
        }

        .cake-card-content {
            padding: 2rem;
            text-align: center;
        }

        .cake-card h3 {
            font-size: 1.5rem;
            color: var(--dark);
            margin-bottom: 1rem;
            font-weight: 600;
        }

        .cake-card p {
            color: #666;
            font-size: 1rem;
            line-height: 1.6;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 768px) {
            .hero-text h1 {
                font-size: 3.5rem;
            }
            
            .hero-text p {
                font-size: 1.2rem;
            }
            
            .cake-card {
                margin-bottom: 2rem;
            }
        }
    </style>
</head>
<body>

  <!-- Navbar -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">Bake With Us 🎂</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav me-3">
            </ul>
            <div>
                <a href="login.php" class="btn btn-danger">Login</a>
                <a href="register.php" class="btn btn-danger">Register</a>
            </div>
        </div>
    </div>
</nav>

    <!-- Hero Section -->
    <div class="hero">
        <div class="hero-text">
            <h1>Elegance in Every Slice 🍰</h1>
            <p>Experience the art of luxury cakes, crafted with passion and precision for your most cherished moments.</p>
            <a href="login.php" class="btn btn-order">Order Now</a>
        </div>
    </div>

    <!-- Cake Selection -->
    <section class="cakes">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-4 col-md-6">
                    <div class="cake-card">
                        <img src="images/choco1.jpg" alt="Chocolate Cake">
                        <div class="cake-card-content">
                            <h3>Golden Chocolate</h3>
                            <p>Rich, creamy & indulgent. A chocolate lover's dream with layers of velvety ganache.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="cake-card">
                        <img src="images/strawberry.jpg" alt="Strawberry Cake">
                        <div class="cake-card-content">
                            <h3>Berry Royal</h3>
                            <p>Fresh strawberries layered with delicate vanilla sponge and mascarpone cream.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="cake-card">
                        <img src="images/vanilla.png" alt="Vanilla Cake">
                        <div class="cake-card-content">
                            <h3>Vanilla Luxe</h3>
                            <p>Madagascar vanilla bean infused buttercream on cloud-like sponge cake.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>
</html>