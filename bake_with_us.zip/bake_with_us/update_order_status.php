<?php  
session_start();
header("Content-Type: application/json");  
include "config.php";  

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST["order_id"]) || empty($_POST["order_id"])) {
        echo json_encode(["status" => "error", "message" => "Order ID is required"]);
        exit();
    }

    $order_id = intval($_POST["order_id"]);
    if ($order_id <= 0) {
        echo json_encode(["status" => "error", "message" => "Invalid Order ID"]);
        exit();
    }

    $new_status = "Completed";
    
    $updateQuery = "UPDATE orders SET delivery_status = ? WHERE order_id = ?";
    $stmt = $conn->prepare($updateQuery);
    
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
        exit();
    }

    $stmt->bind_param("si", $new_status, $order_id);
    
    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Order status updated"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update order status: " . $conn->error]);
    }
    
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
