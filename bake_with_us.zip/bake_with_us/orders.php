<?php
session_start();
include "config.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT 
    o.order_id, o.user_id, o.customer_id, o.total_amount, 
    o.payment_status AS order_payment_status, o.delivery_status,
    o.created_at AS order_date,
    p.payment_id, p.amount AS payment_amount, p.payment_method, p.payment_status, p.payment_date,
    oi.cake_id, oi.quantity AS ordered_quantity, oi.price AS item_price, 
    oi.toppings_json, oi.message_text, oi.special_design,
    c.name AS cake_name, c.image AS cake_image, c.weight, c.type, c.description,
    u.username, u.email, u.mobile_number, u.address
FROM orders o
LEFT JOIN users u ON o.user_id = u.id
LEFT JOIN payments p ON o.order_id = p.order_id
LEFT JOIN order_items oi ON o.order_id = oi.order_id
LEFT JOIN cakes c ON oi.cake_id = c.id
ORDER BY o.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

$pendingOrders = [];
$completedOrders = [];

while ($order = $result->fetch_assoc()) {
    //echo "<pre>"; print_r($order); echo "</pre>"; // Debugging output
    if (trim(strtolower($order["delivery_status"])) === "pending") {
        $pendingOrders[] = $order;
    } else {
        $completedOrders[] = $order;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
    /* Importing Poppins for a clean, modern look */
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

  /* Importing elegant fonts */
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&family=Playfair+Display:wght@400;600;700&display=swap');

body {
    font-family: 'Montserrat', sans-serif;
    background-color: #333;
    background-color: #333;    margin: 0;
    padding: 0;
    background-color: #333;    min-height: 100vh;
}

h2 {
    font-family: 'Playfair Display', serif;
    text-align: center;
    color: #f8d7a4;
    font-size: 2.5rem;
    margin: 40px 0 30px;
    text-shadow: 0 2px 15px rgba(255, 204, 102, 0.3);
    letter-spacing: 1px;
    font-weight: 700;
}

.order-container {
    width: 100%;
    max-width: 1300px;
    margin: 0 auto 60px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 30px;
    padding: 0 20px;
}

.order-card {
    background-color: #333;    backdrop-filter: blur(10px);
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), 
                0 1px 2px rgba(255, 204, 102, 0.1),
                inset 0 1px 1px rgba(255, 255, 255, 0.05);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    position: relative;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.order-card::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 204, 102, 0.1) 0%, transparent 60%);
    opacity: 0;
    transition: opacity 0.4s ease;
    pointer-events: none;
}

.order-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4),
                0 3px 10px rgba(255, 204, 102, 0.2),
                inset 0 1px 1px rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 204, 102, 0.3);
}

.order-card:hover::before {
    opacity: 1;
}

.order-header {
    font-family: 'Playfair Display', serif;
    font-size: 1.5rem;
    color: #f8d7a4;
    margin-bottom: 18px;
    border-bottom: 1px solid rgba(255, 204, 102, 0.2);
    padding-bottom: 12px;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
}

.cake-img {
    width: 140px;
    height: 140px;
    border-radius: 50%;
    object-fit: cover;
    display: block;
    margin: 15px auto;
    transition: all 0.5s ease;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.4),
                0 0 0 5px rgba(255, 204, 102, 0.15);
}

.order-card:hover .cake-img {
    transform: scale(1.08) rotate(5deg);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5),
                0 0 0 8px rgba(255, 204, 102, 0.25);
}

.order-details {
    margin: 15px 0;
    font-size: 0.95rem;
    color: #d0d0d5;
    line-height: 1.6;
}

p {
    margin: 10px 0;
    transition: all 0.3s ease;
}

.order-card:hover p {
    transform: translateY(-2px);
}

.highlight {
    color: #f8d7a4;
    font-weight: 500;
    margin-right: 5px;
}

.show-details-btn {
    background: linear-gradient(135deg, #f8d7a4 0%, #e6a861 100%);
    color:rgb(255, 255, 255);
    padding: 12px 20px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    font-weight: 600;
    font-size: 0.9rem;
    margin-top: 20px;
    transition: all 0.3s ease;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    letter-spacing: 0.5px;
    position: relative;
    overflow: hidden;
    width: 100%;
}

.show-details-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: all 0.5s ease;
}

.show-details-btn:hover {
    background: linear-gradient(135deg, #e6a861 0%, #f8d7a4 100%);
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
}

.show-details-btn:hover::before {
    left: 100%;
}

/* MODAL STYLING */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(10, 10, 15, 0.85);
    backdrop-filter: blur(10px);
    justify-content: center;
    align-items: center;
    opacity: 0;
    transition: opacity 0.4s ease;
}

.modal.show {
    opacity: 1;
    display: flex;
}

.modal-content {
    background: linear-gradient(135deg, rgba(40, 40, 50, 0.95) 0%, rgba(25, 25, 35, 0.95) 100%);
    padding: 35px;
    border-radius: 20px;
    width: 90%;
    max-width: 650px;
    color: #f0f0f0;
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5),
                0 0 0 1px rgba(255, 204, 102, 0.2);
    transform: scale(0.95) translateY(20px);
    transition: all 0.5s cubic-bezier(0.18, 0.89, 0.32, 1.15);
    max-height: 85vh;
    overflow-y: auto;
    position: relative;
}

.modal.show .modal-content {
    transform: scale(1) translateY(0);
}

.modal-content::-webkit-scrollbar {
    width: 8px;
}

.modal-content::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 4px;
}

.modal-content::-webkit-scrollbar-thumb {
    background: rgba(255, 204, 102, 0.3);
    border-radius: 4px;
}

.modal-content h2 {
    font-family: 'Playfair Display', serif;
    color: #f8d7a4;
    font-size: 2rem;
    margin-top: 0;
    margin-bottom: 25px;
    text-align: center;
    position: relative;
}

.modal-content h2::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 3px;
    background: linear-gradient(90deg, transparent, #f8d7a4, transparent);
}

.modal-content p {
    margin: 14px 0;
    display: flex;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    padding-bottom: 10px;
}

.modal-content p span.highlight {
    min-width: 120px;
}

.modal-content .cake-img {
    width: 180px;
    height: 180px;
    margin: 20px auto;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3),
                0 0 0 10px rgba(255, 204, 102, 0.1);
}

.close-btn {
    background: linear-gradient(135deg, #ff4d4d 0%, #cc0000 100%);
    color: white;
    padding: 12px 25px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    margin-top: 25px;
    font-weight: 600;
    font-size: 1rem;
    transition: all 0.3s ease;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    display: block;
    width: 100%;
    max-width: 200px;
    margin: 25px auto 0;
}

.close-btn:hover {
    background: linear-gradient(135deg, #cc0000 0%, #ff4d4d 100%);
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .order-container {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        padding: 0 15px;
    }
    
    h2 {
        font-size: 2rem;
        margin: 30px 0 20px;
    }
    
    .modal-content {
        padding: 25px;
        max-width: 90%;
    }
}

/* Animation for new orders */
@keyframes newOrderPulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.03); }
    100% { transform: scale(1); }
}

.new-order {
    animation: newOrderPulse 2s infinite;
    border: 1px solid rgba(255, 204, 102, 0.5);
}
/* Navbar Styling */
.navbar {

    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 20px;
}

/* Navbar Container */
.containe {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;

}

/* Navbar Brand */
.navbar-brand {
    font-family: 'Great Vibes', cursive;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;
            text-decoration: none;
}

/* Navbar Navigation */
.navbar-nav {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 15px;
}

/* Navbar Items */
.nav-item {
    display: flex;
    align-items: center;
}

/* Navbar Links */
.nav-link {
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Responsive Navbar */
@media (max-width: 991px) {
    .navbar {
        flex-direction: column;
        align-items: center;
    }

    .navbar-nav {
        flex-direction: column;
        width: 100%;
        align-items: center;
    }

    .nav-item {
        width: 100%;
        display: flex;
        justify-content: center;
    }

    .nav-link {
        width: 100%;
        justify-content: center;
    }
}
        .navbar {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
        }
        .navbar-brand {
            font-size: 2rem;
            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;
            text-decoration: none;
        }
        .nav-link {
            color: #FFD700 !important;
            font-weight: 500;
            transition: all 0.3s ease-in-out;
            text-decoration: none;
        }
        .nav-link:hover {
            color: #ffcc33 !important;
            text-shadow: 0px 0px 5px rgba(255, 223, 186, 0.8);
        }

/* Status update button */
.update-status-btn {
    background: linear-gradient(135deg, #4CAF50 0%, #2E7D32 100%);
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    font-weight: 600;
    font-size: 0.85rem;
    margin-top: 10px;
    transition: all 0.3s ease;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    letter-spacing: 0.5px;
    position: relative;
    overflow: hidden;
    width: 100%;
}

.update-status-btn:hover {
    background: linear-gradient(135deg, #2E7D32 0%, #4CAF50 100%);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
}

/* Toast notification */
.toast {
    position: fixed;
    top: 20px;
    right: 20px;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 15px 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    z-index: 2000;
    display: none;
    transition: all 0.3s ease;
}

.toast.success {
    border-left: 5px solid #4CAF50;
}

.toast.error {
    border-left: 5px solid #F44336;
}

</style>
</head>
<body>
    
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">

  
    <div class="containe">
        <a class="navbar-brand" style="margin-left: 100px; margin-right:400px;" href="admin.php">Bake With Us 🎂</a>
        
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="admin.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="add_cake.php">Manage Cakes</a></li>
                <li class="nav-item"><a class="nav-link" href="orders.php">Orders</a></li>
             
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
    </div>
</nav>

<!-- Toast notification -->
<div id="toast" class="toast">
    <span id="toast-message"></span>
</div>

<h2>🍰 My Cake Orders 🍰</h2>

<!-- Pending Deliveries -->
<h3 style="text-align: center; color: #f8d7a4; margin: 40px 0 20px;">🚧 Pending Orders</h3>
<div class="order-container">
    <?php if (!empty($pendingOrders)) {
        foreach ($pendingOrders as $order) { ?>
            <div class="order-card">
                <div class="order-header">Order #<?php echo htmlspecialchars($order["order_id"]); ?></div>
                <img src="uploads/<?php echo htmlspecialchars($order["cake_image"]); ?>" alt="Cake" class="cake-img">
                <p><span class="highlight">Cake:</span> <?php echo htmlspecialchars($order["cake_name"]); ?></p>
                <p><span class="highlight">Quantity:</span> <?php echo htmlspecialchars($order["ordered_quantity"]); ?></p>
                <p><span class="highlight">Price:</span> ₹<?php echo number_format($order["item_price"], 2); ?></p>
                <p><span class="highlight">Status:</span> <span style="color:orange;"><?php echo htmlspecialchars($order["delivery_status"]); ?></span></p>
                <button class="show-details-btn" data-order='<?php echo json_encode($order); ?>'>Show Full Details</button>
                <button class="update-status-btn" data-id="<?php echo $order["order_id"]; ?>">Mark as Completed</button>
            </div>
    <?php }
    } else { ?>
        <p class="no-orders" style="text-align: center; color: #d0d0d5; grid-column: 1 / -1;">No pending orders.</p>
    <?php } ?>
</div>

<!-- Completed Deliveries -->
<h3 style="text-align: center; color: #f8d7a4; margin: 40px 0 20px;">✅ Completed Orders</h3>
<div class="order-container">
    <?php if (!empty($completedOrders)) {
        foreach ($completedOrders as $order) { ?>
            <div class="order-card">
                <div class="order-header">Order #<?php echo htmlspecialchars($order["order_id"]); ?></div>
                <img src="uploads/<?php echo htmlspecialchars($order["cake_image"]); ?>" alt="Cake" class="cake-img">
                <p><span class="highlight">Cake:</span> <?php echo htmlspecialchars($order["cake_name"]); ?></p>
                <p><span class="highlight">Quantity:</span> <?php echo htmlspecialchars($order["ordered_quantity"]); ?></p>
                <p><span class="highlight">Price:</span> ₹<?php echo number_format($order["item_price"], 2); ?></p>
                <p><span class="highlight">Status:</span> <span style="color:green;"><?php echo htmlspecialchars($order["delivery_status"]); ?></span></p>
                <button class="show-details-btn" data-order='<?php echo json_encode($order); ?>'>Show Full Details</button>
            </div>
    <?php }
    } else { ?>
        <p class="no-orders" style="text-align: center; color: #d0d0d5; grid-column: 1 / -1;">No completed orders.</p>
    <?php } ?>
</div>

<!-- Modal -->
<div id="orderModal" class="modal">
    <div class="modal-content">
        <h2>Order Details</h2>
        <p><span class="highlight">Order ID:</span> <span id="modal-order-id"></span></p>
        <img id="modal-cake-img" src="" alt="Cake Image" class="cake-img">
        <p><span class="highlight">Cake:</span> <span id="modal-cake-name"></span></p>
        <p><span class="highlight">Weight:</span> <span id="modal-cake-weight"></span></p>
        <p><span class="highlight">Type:</span> <span id="modal-cake-type"></span></p>
        <p><span class="highlight">Description:</span> <span id="modal-description"></span></p>
        <p><span class="highlight">Quantity:</span> <span id="modal-quantity"></span></p>
        <p><span class="highlight">Price:</span> ₹<span id="modal-price"></span></p>
        <p><span class="highlight">Stuffing:</span> <span id="modal-toppings"></span></p>
        <p><span class="highlight">Message:</span> <span id="modal-message"></span></p>
        <p><span class="highlight">Special Design:</span> <span id="modal-special-design"></span></p>
        <p><span class="highlight">Ordered by:</span> <span id="modal-username"></span></p>
        <p><span class="highlight">Email:</span> <span id="modal-email"></span></p>
        <p><span class="highlight">Phone:</span> <span id="modal-phone"></span></p>
        <p><span class="highlight">Address:</span> <span id="modal-address"></span></p>
        <p><span class="highlight">Order Status:</span> <span id="modal-order-status"></span></p>
        <p><span class="highlight">Delivery Status:</span> <span id="modal-delivery-status"></span></p>
        <p><span class="highlight">Payment:</span> <span id="modal-payment"></span></p>
        <p><span class="highlight">Order Date:</span> <span id="modal-order-date"></span></p>
        <button class="close-btn" onclick="closeModal()">Close</button>
    </div>
</div>

<script>
    $(".show-details-btn").click(function() {
        let order = JSON.parse($(this).attr("data-order"));
        $("#modal-order-id").text(order.order_id);
        $("#modal-cake-img").attr("src", "uploads/" + order.cake_image);
        $("#modal-cake-name").text(order.cake_name);
        $("#modal-cake-weight").text(order.weight);
        $("#modal-cake-type").text(order.type);
        $("#modal-description").text(order.description);
        $("#modal-quantity").text(order.ordered_quantity);
        $("#modal-price").text(order.item_price);
        $("#modal-toppings").text(order.toppings_json);
        $("#modal-message").text(order.message_text);
        $("#modal-special-design").text(order.special_design);
        $("#modal-username").text(order.username);
        $("#modal-email").text(order.email);
        $("#modal-phone").text(order.mobile_number);
        $("#modal-address").text(order.address);
        $("#modal-order-status").text(order.order_payment_status);
        $("#modal-delivery-status").text(order.delivery_status);
        $("#modal-payment").text(order.payment_status + " via " + order.payment_method);
        $("#modal-order-date").text(order.order_date);

        $("#orderModal").fadeIn().addClass("show");
    });

    function closeModal() {
        $("#orderModal").fadeOut().removeClass("show");
    }

    // Update order status
    $(".update-status-btn").click(function() {
        const orderId = $(this).data("id");
        const cardElement = $(this).closest(".order-card");
        
        $.ajax({
            url: "update_order_status.php",
            type: "POST",
            data: {
                order_id: orderId,
                status: "Completed"
            },
            dataType: "json",
            success: function(response) {
                if (response.status === "success") {
                    showToast("Order status updated successfully!", "success");
                    // Remove card from pending and add to completed
                    cardElement.fadeOut(500, function() {
                        // Find the completed orders container
                        const completedContainer = $(".order-container").eq(1);
                        
                        // Change the status color in the card
                        cardElement.find("p:contains('Status')").find("span").css("color", "green");
                        
                        // Remove the update button
                        cardElement.find(".update-status-btn").remove();
                        
                        // Move the card to the completed section
                        cardElement.appendTo(completedContainer).fadeIn(500);
                    });
                } else {
                    showToast("Error: " + response.message, "error");
                }
            },
            error: function() {
                showToast("An error occurred. Please try again.", "error");
            }
        });
    });

    // Toast notification function
    function showToast(message, type) {
        const toast = $("#toast");
        $("#toast-message").text(message);
        
        // Add type class
        toast.removeClass("success error").addClass(type);
        
        // Show the toast
        toast.fadeIn();
        
        // Hide after 3 seconds
        setTimeout(function() {
            toast.fadeOut();
        }, 3000);
    }
</script>

</body>
</html>