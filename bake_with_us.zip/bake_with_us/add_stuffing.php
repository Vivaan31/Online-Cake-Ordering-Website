<?php
// Initialize session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include "config.php";

// Check if user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Check if required fields are set
if (!isset($_POST["cake_id"]) || !isset($_POST["stuffing_name"]) || !isset($_POST["stuffing_price"])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit();
}

// Validate inputs
if (!is_numeric($_POST["cake_id"]) || empty($_POST["stuffing_name"]) || !is_numeric($_POST["stuffing_price"])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid input values']);
    exit();
}

// Sanitize inputs
$cake_id = (int)$_POST["cake_id"];
$stuffing_name = trim(htmlspecialchars($_POST["stuffing_name"]));
$stuffing_price = (float)$_POST["stuffing_price"];

// Verify cake exists
$cake_check = $conn->prepare("SELECT id FROM cakes WHERE id = ?");
$cake_check->bind_param("i", $cake_id);
$cake_check->execute();
$cake_result = $cake_check->get_result();

if ($cake_result->num_rows === 0) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Cake not found']);
    $cake_check->close();
    exit();
}
$cake_check->close();

// Insert new stuffing using prepared statement
$stmt = $conn->prepare("INSERT INTO extra_stuffing (cake_id, stuffing_name, stuffing_price) VALUES (?, ?, ?)");
$stmt->bind_param("isd", $cake_id, $stuffing_name, $stuffing_price);

if ($stmt->execute()) {
    $id = $conn->insert_id;
    
    // Return success response with stuffing data
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'message' => 'Stuffing added successfully',
        'stuffing' => [
            'id' => $id,
            'name' => $stuffing_name,
            'price' => number_format($stuffing_price, 2)
        ]
    ]);
} else {
    // Return error response
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $stmt->error
    ]);
}

// Close statement
$stmt->close();
?>