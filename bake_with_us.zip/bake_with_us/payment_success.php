<?php
if (isset($_GET['payment_id'])) {
    $payment_id = $_GET['payment_id'];
    
    // Database connection
    $conn = new mysqli("localhost", "root", "", "your_database");
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Store payment details
    $query = "INSERT INTO payments (payment_id, amount, status) VALUES ('$payment_id', '500', 'success')";
    
    if ($conn->query($query) === TRUE) {
        echo "Payment Successful!";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    echo "Payment Failed!";
}
?>
