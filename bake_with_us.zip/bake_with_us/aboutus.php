<?php
session_start();
include "config.php"; // Database connection

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}
?>

<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bake With Us - Exquisite Cakes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">


   <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            padding-top: 80px; 
            background-color: #f8f9fa; 
        }
        
        /* Navbar styling */
        .navbar {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 10px rgba(255, 223, 186, 0.3);
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 2rem;
            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;
        }
        .nav-link {
            color: #FFD700 !important;
            font-weight: 500;
            transition: all 0.3s ease-in-out;
        }
        .nav-link:hover {
            color: #ffcc33 !important;
            text-shadow: 0px 0px 5px rgba(255, 223, 186, 0.8);
        }
    .about-container {
        padding: 60px 0;
        background: linear-gradient(rgba(255, 245, 230, 0.9), rgba(255, 245, 230, 0.9)),
                    url('https://images.unsplash.com/photo-1557925923-cd4648e211a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
        background-size: cover;
        background-position: center;
        min-height: 80vh;
    }

    .about-content {
        max-width: 1200px;
        margin: 0 auto;
        padding: 40px;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .about-container h2 {
        font-family: 'Great Vibes', cursive;
        font-size: 4rem;
        color: #d35400;
        margin-bottom: 30px;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
    }

    .about-container p {
        font-size: 1.1rem;
        line-height: 1.8;
        color: #555;
        margin-bottom: 25px;
        text-align: justify;
    }

    .highlight {
        color: #d35400;
        font-weight: 600;
    }

    .team-section {
        padding: 50px 0;
        text-align: center;
    }

    .team-member {
        
        margin: 20px;
        padding: 20px;
        background: white;
        border-radius: 15px;
        transition: transform 0.3s ease;
    }

    .team-member:hover {
        transform: translateY(-10px);
    }

    .team-member img {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        margin-bottom: 15px;
        border: 3px solid #ffd700;
    }

    .footer {
        background: #2c1810;
        color: #fff;
        padding: 40px 0;
        text-align: center;
    }

    .footer a {
        color: #ffd700;
        text-decoration: none;
        margin: 0 10px;
    }

    .footer a:hover {
        color: #ffcc33;
    }

    .contact-info {
        margin: 20px 0;
        font-size: 1.1rem;
    }

    .contact-info i {
        margin-right: 10px;
        color: #ffd700;
    }

    .social-icons {
        margin-top: 20px;
    }

    .social-icons a {
        font-size: 24px;
        margin: 0 15px;
        transition: all 0.3s ease;
    }

    .divider {
        border-top: 2px solid #ffd700;
        width: 60px;
        margin: 30px auto;
    }
        </style>
</head>
<body>
<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">Bake With Us 🎂</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="cakes.php">Cakes</a></li>
                <li class="nav-item"><a class="nav-link" href="aboutus.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="user.php">Profile</a></li>

                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                        <span id="cartCount" class="badge bg-danger rounded-pill">0</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="btn btn-danger rounded-pill shadow-sm">
                        <i class="fa-solid fa-right-from-bracket "></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="about-container">
    <div class="about-content">
       <center> <h2>Our Story</h2> </center>
        <div class="divider"></div>
        <div class="row">
            <div class="col-lg-6">
                <p class="highlight">Welcome to Bake With Us, where every cake tells a story!</p>
                <p>Founded in 2024, our bakery has grown from a small home kitchen to one of the most beloved cake destinations in the region. What started as a passion project has blossomed into a thriving community of cake enthusiasts and flavor explorers.</p>
                <p>We believe in crafting more than just cakes - we create edible works of art that engage all your senses. Our team of award-winning bakers and decorators combines traditional techniques with innovative designs to bring your sweetest dreams to life.</p>
            </div>
            <div class="col-lg-6">
                <img src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-1.2.1&auto=format&fit=crop&w=1089&q=80" 
                     alt="Our Kitchen" 
                     class="img-fluid rounded-3 shadow-lg"
                     style="border: 5px solid #ffd700;">
            </div>
        </div>

        <div class="team-section">
            <h3 class="mb-5" style="color: #d35400;">Meet Our Master Bakers</h3>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="team-member">
                        <img src="images/baker2.jpeg" alt="Head Baker">
                        <h4>Sarah Johnson</h4>
                        <center> <p>Head Pastry Chef</p></center>
                        <p>15 years experience in French of Cakes and Pastries</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="team-member">
                        <img src="images/baker1.jpeg" alt="Cake Designer">
                        <h4>Michael Chen</h4>
                        <center><p>Lead Cake Artist</p></center>
                        <p>Specialist in modern cake Flavours and Designs</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Footer -->
<div class="footer">
    <div class="container">
        <h4 class="mb-4">Connect With Us</h4>
        <div class="contact-info">
            <p><i class="fas fa-phone"></i>+91-9913344457</p>
            <p><i class="fas fa-envelope"></i>bakewithus@gmail.com</p>
        </div>
        
        <div class="social-icons">
            <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="#" target="_blank"><i class="fab fa-pinterest"></i></a>
            <a href="#" target="_blank"><i class="fab fa-tiktok"></i></a>
        </div>
        
        <div class="divider"></div>
        <p class="mt-4 mb-0">&copy; 2024 Bake With Us. Crafted with <i class="fas fa-heart" style="color: #ff6b6b;"></i> in Every Bite</p>
    </div>
</div>