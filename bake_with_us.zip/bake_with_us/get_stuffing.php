<?php

    session_start();


// Database connection
require_once 'config.php';


if (isset($_GET["cake_id"])) {
    $cake_id = intval($_GET["cake_id"]);
    $sql = "SELECT stuffing_name, stuffing_price FROM extra_stuffing WHERE cake_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cake_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $stuffingOptions = [];
    while ($row = $result->fetch_assoc()) {
        $stuffingOptions[] = $row;
    }

    echo json_encode($stuffingOptions);
} else {
    echo json_encode(["error" => "No cake ID provided"]);
}

$conn->close();
?>
