<?php
session_start();
include "config.php"; // Include database connection

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["profile_image"])) {
    $target_dir = "uploads/";
    $file_name = time() . "_" . basename($_FILES["profile_image"]["name"]); // Unique filename
    $target_file = $target_dir . $file_name;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // Check file type (only allow jpg, png, jpeg)
    $allowed_types = array("jpg", "jpeg", "png");
    if (!in_array($imageFileType, $allowed_types)) {
        echo "Only JPG, JPEG, and PNG files are allowed.";
        exit();
    }

    // Move uploaded file
    if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
        // Update database with new profile image
        $query = "UPDATE users SET profile_image = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("si", $file_name, $user_id);
        $stmt->execute();
        $stmt->close();

        $_SESSION['profile_image'] = $file_name; // Update session variable

        header("Location: user.php");
        exit();
    } else {
        echo "Error uploading file.";
    }
}
?>
