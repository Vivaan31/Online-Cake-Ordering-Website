<?php
session_start(); // Start session
include 'config.php'; // Ensure correct database connection


if (!isset($_SESSION["user_id"])) {
    echo json_encode(["status" => "error", "message" => "User not logged in"]);
    exit;
}

$user_id = $_SESSION["user_id"]; // Retrieve user ID from session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cake_id = $_POST["cake_id"];
    $rating = $_POST["rating"];
    $comment = $_POST["comment"];

    if (empty($cake_id) || empty($rating) || empty($comment)) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    // Insert into database
    $sql = "INSERT INTO reviews (cake_id, user_id, rating, comment) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiis", $cake_id, $user_id, $rating, $comment);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }

    $stmt->close();
    $conn->close();
}
?>
