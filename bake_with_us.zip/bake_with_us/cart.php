<?php
session_start();
include "config.php"; // Include database connection
// Set default values if not provided

// Set default values if not provided
$razorpayKey = !empty($razorpayKey) ? $razorpayKey : "rzp_test_c24H9ZLQiaptXy"; // Default Test Key
$razorpaySecret = !empty($razorpaySecret) ? $razorpaySecret : "1lYb6jpCbe3bNqwX3ZnLF18L"; // Default Secret Key

$provider_name = !empty($provider_name) ? htmlspecialchars($provider_name) : "Default Provider";
$orderDescription = !empty($orderDescription) ? htmlspecialchars($orderDescription) : "Order Payment";
$final_total_paise = !empty($final_total_paise) ? intval($final_total_paise) : 1000; // Default to ₹10.00
$item_count = isset($item_count) ? intval($item_count) : 1; // Default to 1 item



// Place this at the top to handle payment notifications
function displayPaymentNotifications() {
    $output = '';
    
    if (isset($_SESSION['payment_error'])) {
        $error = $_SESSION['payment_error'];
        $output .= <<<HTML
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i> {$error}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        HTML;
        unset($_SESSION['payment_error']);
    }
    
    if (isset($_SESSION['payment_success']) && !isset($_SESSION['order_id'])) {
        $output .= <<<HTML
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> Your payment was successful!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        HTML;
        unset($_SESSION['payment_success']);
    }
    
    return $output;
}

// Fetch cart data
$sql = "SELECT * FROM cart";
$result = $conn->query($sql);

// Handle delete action
if (isset($_POST['delete']) && isset($_POST['cart_id'])) {
    $cart_id = intval($_POST['cart_id']);
    $delete_sql = "DELETE FROM cart WHERE cart_id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $cart_id);
    $stmt->execute();
    
    // Redirect to refresh the page
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
// Handle edit form submission
if (isset($_POST['update']) && isset($_POST['cart_id'])) {
    require_once 'config.php'; // Ensure database connection is included

    $cart_id = intval($_POST['cart_id']);
    $quantity = intval($_POST['quantity']);
    $message_text = trim($_POST['message_text']);

    // Fetch existing cart details
    $stmt = $conn->prepare("SELECT base_price, extras_cost, toppings_json FROM cart WHERE cart_id = ?");
    $stmt->bind_param("i", $cart_id);
    $stmt->execute();
    $cart_item = $stmt->get_result()->fetch_assoc();

    if (!$cart_item) {
        die("Cart item not found.");
    }

    $base_price = floatval($cart_item['base_price']);
    $extras_cost = floatval($cart_item['extras_cost']);
    $toppings_json = $cart_item['toppings_json']; // Keep toppings unchanged

    // Adjust extras cost if a message is present
    $special_design = !empty($message_text) ? 1 : 0;
    if ($special_design) {
        $extras_cost += 0; // Add extra charge for a special message
    }

    // Calculate total price
    $item_total = ($base_price * $quantity) + $extras_cost;

    // Update the cart item
    $update_sql = "UPDATE cart SET 
                   quantity = ?, 
                   message_text = ?, 
                   extras_cost = ?, 
                   item_total = ?, 
                   updated_at = NOW()
                   WHERE cart_id = ?";

    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("isdii", $quantity, $message_text, $extras_cost, $item_total, $cart_id);
    $stmt->execute();

    // Redirect to refresh the page
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Initialize variables for cart summary
$cart_total = 0;
$item_count = 0;

// Initialize arrays to store Razorpay details
$cake_details = [];
$razorpay_details = [];

// First pass through results to calculate totals and collect cake_ids
$cake_ids = [];
if ($result->num_rows > 0) {
    // Store original result pointer position
    $temp_result = $result;
    
    while($row = $temp_result->fetch_assoc()) {
        if (isset($row['order_status']) && strtolower($row['order_status']) === 'paid') {
            continue; // Skip adding this item's total
        }
        
        $cart_total += $row['item_total'];
        $item_count++;
        
        // Collect unique cake IDs to fetch details later
        if (isset($row['cake_id']) && !in_array($row['cake_id'], $cake_ids)) {
            $cake_ids[] = $row['cake_id'];
        }
    }
    
    // Reset the result pointer for later use in the display loop
    $result->data_seek(0);
}

// If we have cake IDs, fetch their details
if (!empty($cake_ids)) {
    $cake_ids_str = implode(',', $cake_ids);
    $cakesQuery = "SELECT c.id, c.name, c.price, c.user_id, c.weight 
                  FROM cakes c 
                  WHERE c.id IN ($cake_ids_str)";
    $cakesResult = $conn->query($cakesQuery);
    
    if ($cakesResult && $cakesResult->num_rows > 0) {
        $user_ids = [];
        
        while($cakeRow = $cakesResult->fetch_assoc()) {
            $cake_details[$cakeRow['id']] = $cakeRow;
            
            // Collect unique user IDs to fetch Razorpay details later
            if (!in_array($cakeRow['user_id'], $user_ids)) {
                $user_ids[] = $cakeRow['user_id'];
            }
        }
        
        // If we have user IDs, fetch their Razorpay details
        if (!empty($user_ids)) {
            $user_ids_str = implode(',', $user_ids);
            $razorpayQuery = "SELECT user_id, provider_name, razorpay_key, razorpay_secret 
                             FROM accounts_details 
                             WHERE user_id IN ($user_ids_str)";
            $razorpayResult = $conn->query($razorpayQuery);
            
            if ($razorpayResult && $razorpayResult->num_rows > 0) {
                while($razorpayRow = $razorpayResult->fetch_assoc()) {
                    $razorpay_details[$razorpayRow['user_id']] = $razorpayRow;
                }
            }
        }
    }
}


$delivery_fee = 9.99;
$tax_rate = 0.08;
$tax_amount = $cart_total * $tax_rate;
$final_total = $cart_total + $delivery_fee + $tax_amount;
$final_total_paise = (int) round($final_total * 100); // Ensure integer format

// Find the primary cake seller (for payment processing)
// We'll use the seller of the first cake in the cart
$primary_user_id = null;
$primary_cake_id = null;
$provider_name = "Shop Owner";
$razorpayKey = "rzp_test_default_key";
$razorpay_secret = "";

if ($result->num_rows > 0) {
    $result->data_seek(0);
    $first_item = $result->fetch_assoc();
    if (isset($first_item['cake_id']) && isset($cake_details[$first_item['cake_id']])) {
        $primary_cake_id = $first_item['cake_id'];
        $primary_user_id = $cake_details[$primary_cake_id]['user_id'];
        
        if (isset($razorpay_details[$primary_user_id])) {
            $provider_name = $razorpay_details[$primary_user_id]['provider_name'];
            $razorpayKey = $razorpay_details[$primary_user_id]['razorpay_key'];
            $razorpay_secret = $razorpay_details[$primary_user_id]['razorpay_secret'];
        }
    }
    $result->data_seek(0);
}

// Create an order description
$orderDescription = "Order for " . $item_count . " items";
if ($primary_cake_id && isset($cake_details[$primary_cake_id])) {
    $orderDescription = "Order including " . $cake_details[$primary_cake_id]['name'];
    if (isset($cake_details[$primary_cake_id]['weight'])) {
        $orderDescription .= " (" . $cake_details[$primary_cake_id]['weight'] . ")";
    }
}



// Check if user is logged in
$cartCount = 0;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Query to count items where order_status is pending
    $query = "SELECT COUNT(*) AS count FROM cart WHERE user_id = ? AND order_status = 'pending'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($cartCount);
    $stmt->fetch();
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sweet Delights - Your Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
       
        
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', sans-serif;
            color: var(--dark-color);
            
        }
        
               /* Navbar styling */
               .navbar {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 10px rgba(255, 223, 186, 0.3);
            margin-bottom: 30px;
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 2rem;
            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;
        }
        .nav-link {
            color: #FFD700 !important;
            font-weight: 500;
            transition: all 0.3s ease-in-out;
        }
        .nav-link:hover {
            color: #ffcc33 !important;
            text-shadow: 0px 0px 5px rgba(255, 223, 186, 0.8);
        }
        
        .cart-header {
            background: #253342;
            color: white;
            border-radius: 15px 15px 0 0;
            padding: 35px;
            margin-bottom: 0;
            position: relative;
            overflow: hidden;
        }
        
        .cart-header::after {
            content: "";
            position: absolute;
            right: -20px;
            bottom: -20px;
            width: 150px;
            height: 150px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .cart-container {
            max-width: 1200px;
           
            margin: 40px auto;
            box-shadow: 10px 10px 10px 10px black;
            border-radius: 15px;
            background-color:whitesmoke;
            overflow: hidden;
        }
        
        .cart-body {
            padding: 30px;
        }
        
        .cart-item {
            background-color:#253342;
            border-radius: 12px;
            margin-bottom: 20px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden;
            position: relative;
        }
        
        .cart-item:hover {
            transform: translateY(-5px);
            box-shadow: 10px 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .item-image {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px 0 0 12px;
        }
        
        .item-image img {
            max-width: 100%;
            height: auto;
            object-fit: cover;
        }
        
        .cake-icon {
            font-size: 48px;
            color: var(--accent-color);
        }
        
        .item-details {
            padding: 20px;
        }
        
        .item-title {
            font-weight: 600;
            font-size: 1.2rem;
            margin-bottom: 10px;
            color: var(--dark-color);
        }
        
        .item-price {
            font-weight: 700;
            font-size: 1.3rem;
            color: var(--accent-color);
        }
        
        .item-quantity {
            background-color: rgba(249, 107, 107, 0.1);
            border-radius: 50px;
            padding: 5px 12px;
            display: inline-block;
            font-weight: 600;
        }
        
        .item-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn-view {
            background-color: green;
            color: white;
            border: none;
            border-radius: 50px;
            padding: 8px 20px;
            transition: all 0.3s ease;
        }
        
        .btn-view:hover {
            background-color: #ff5252;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.4);
        }
        
        .btn-edit {
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 50px;
            padding: 8px 20px;
            transition: all 0.3s ease;
        }
        
        .btn-edit:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
        }
        
        .btn-delete {
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 50px;
            padding: 8px 20px;
            transition: all 0.3s ease;
        }
        
        .btn-delete:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.4);
        }
        
        .cart-summary {
         
    background-color: #253342;

            border-radius: 12px;
            padding: 30px;
            margin-top: 20px;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            font-size: 1.1rem;
        }
        
        .summary-label {
            color: #7f8c8d;
        }
        
        .summary-value {
            font-weight: 600;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 2px dashed #e0e0e0;
            font-size: 1.4rem;
            font-weight: 700;
        }
        
        .checkout-btn {
            background: linear-gradient(to right, var(--primary-color), var(--accent-color));
            color: white;
            border: 2px solid white;
            box-shadow: white;
            border-radius: 50px;
            padding: 15px 40px;
            font-size: 1.1rem;
            font-weight: 600;
            margin-top: 20px;
            transition: all 0.3s ease;
            width: 100%;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        
        .checkout-btn::before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(to right, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.4), rgba(255, 255, 255, 0.1));
            transition: all 0.5s ease;
            z-index: -1;
        }
        
        .checkout-btn:hover::before {
            left: 100%;
        }
        
        .checkout-btn:hover {
            box-shadow: 0 10px 20px rgba(249, 107, 107, 0.4);
            transform: translateY(-3px);
        }
        
        .continue-btn {
            background-color: transparent;
            color: white;
            border: 2px solid white;
            box-shadow: white;

            border-radius: 50px;
            padding: 12px 25px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .continue-btn:hover {
            border-color: var(--accent-color);
            color: var(--accent-color);
            transform: translateY(-2px);
        }
        
        .modal-content {
            border-radius: 15px;
            overflow: hidden;
        }
        
        .modal-header {
            background: black;
            color: white;
            border-bottom: none;
            padding: 20px 30px;
        }
        
        .modal-body {
            padding: 30px;
        }
        
        .detail-item {
            margin-bottom: 20px;
            border-bottom: 1px solid #f1f1f1;
            padding-bottom: 15px;
        }
        
        .detail-label {
            font-weight: 600;
            color: #7f8c8d;
            margin-bottom: 5px;
        }
        
        .edit-form {
            background-color: #f9f9f9;
            border-radius: 12px;
            padding: 25px;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 8px;
        }
        
        .form-control {
            border-radius: 8px;
            border: 2px solid #e0e0e0;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(240, 98, 146, 0.25);
        }
        
        .form-check-input:checked {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
        }
        
        .topping-option {
            background-color: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        
        .topping-option:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }
        
        .empty-cart {
            text-align: center;
            padding: 50px 20px;
        }
        
        .empty-cart-icon {
            font-size: 80px;
            color: #e0e0e0;
            margin-bottom: 20px;
        }
        
        .payment-modal .modal-body {
            background-color: #253342;

                padding: 30px;
        }
        
        .payment-option {
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .payment-option:hover {
            border-color: var(--accent-color);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .payment-option.selected {
            border-color: var(--accent-color);
            background-color: rgba(240, 98, 146, 0.05);
        }
        
        .payment-option-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .payment-icon {
            font-size: 24px;
            margin-right: 15px;
            color: var(--accent-color);
        }
        
        .payment-option-title {
            font-weight: 600;
            margin-bottom: 0;
        }
        
        .credit-card-form {
            padding-top: 20px;
        }
        
        .secure-badge {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
            color: #27ae60;
            font-weight: 600;
        }
        
        @media (max-width: 768px) {
            .cart-item {
                flex-direction: column;
            }
            
            .item-image {
                border-radius: 12px 12px 0 0;
                min-height: 150px;
            }
            
            .item-actions {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>

 
<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" style="            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;" href="#">Bake With Us 🎂</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="cakes.php">Cakes</a></li>
                <li class="nav-item"><a class="nav-link active" href="aboutus.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="user.php">Profile</a></li>
                <li class="nav-item">
    <a class="nav-link" href="cart.php">
        <i class="fas fa-shopping-cart"></i>
        <span id="cartCountx" class="badge bg-danger rounded-pill">
            <?php echo $cartCount; ?>
        </span>
    </a>
</li>

                <li class="nav-item">
                    <a href="logout.php" class="btn btn-danger rounded-pill shadow-sm">
                        <i class="fa-solid fa-right-from-bracket "></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
   
    <div class="cart-container">
        <div class="cart-header">
            <h1 class="fs-2 mb-0"><i class="fas fa-shopping-basket me-2"></i> Your Delicious Collection</h1>
            <p class="mb-0 mt-2 opacity-75">Review and customize your sweet selections</p>
        </div>
        
        <div class="cart-body">
            <?php if ($result->num_rows > 0): ?>
                <div class="row">
                    <div class="col-lg-8">
                    <?php 
    $cart_total = 0;
    $item_count = 0;

    while ($row = $result->fetch_assoc()): 
        if ($row['order_status'] === 'paid') {
            continue;
        }

        $cart_total += $row['item_total'];
        $item_count++;

        // Fetch cake details from the 'cake' table
        $cake_id = $row['cake_id'];
        $cake_query = "SELECT name, image FROM cakes WHERE id = ?";
        $stmt = $conn->prepare($cake_query);
        $stmt->bind_param("i", $cake_id);
        $stmt->execute();
        $cake_result = $stmt->get_result();
        $cake = $cake_result->fetch_assoc();

        // Assign values
        $cake_name = $cake ? $cake['name'] : "Delicious Cake #" . $cake_id;
        $cake_image = $cake ? $cake['image'] : 'default-image.jpg'; // Provide a fallback image

        $stmt->close();
    ?>
                        <div class="cart-item d-flex">
                            <div class="item-image col-md-3">
                                <img src="uploads/<?php echo $cake_image; ?>"  alt="">
                        </div>
                            <div class="item-details col-md-9">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h3 class="item-title"><?php echo $cake_name; ?></h3>
                                        <span class="item-quantity"><i class="fas fa-times me-1"></i><?php echo $row['quantity']; ?></span>
                                        <?php if($row['special_design']): ?>
                                            <span class="badge bg-info ms-2"><i class="fas fa-magic me-1"></i>Custom Design</span>
                                        <?php endif; ?>
                                    </div>
                                    <h4 class="item-price">₹<?php echo number_format($row['item_total'], 2); ?></h4>
                                </div>
                                
                                <p class="text-muted mb-4">
                                    <?php if(!empty($toppings_list)): ?>
                                        <small><i class="fas fa-plus-circle me-1"></i><?php echo $toppings_list; ?></small>
                                    <?php endif; ?>
                                </p>
                                
                                <div class="item-actions">
                                    <button class="btn btn-view" data-bs-toggle="modal" data-bs-target="#detailsModal<?php echo $row['cart_id']; ?>">
                                        <i class="fas fa-eye me-1"></i> View Details
                                    </button>
                                    <button class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $row['cart_id']; ?>">
                                        <i class="fas fa-edit me-1"></i> Edit
                                    </button>
                                    <button class="btn btn-delete" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $row['cart_id']; ?>">
                                        <i class="fas fa-trash-alt me-1"></i> Remove
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Details Modal -->
                        <div class="modal fade" id="detailsModal<?php echo $row['cart_id']; ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title"><i class="fas fa-info-circle me-2"></i>Item Details</h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-center mb-4">
                                            <i class="fas fa-birthday-cake" style="font-size: 64px; color: var(--accent-color);"></i>
                                            <h3 class="mt-3"><?php echo $cake_name; ?></h3>
                                        </div>
                                        
                                        <div class="detail-item">
                                            <div class="detail-label">Quantity</div>
                                            <div class="fs-5"><?php echo $row['quantity']; ?></div>
                                        </div>
                                        
                                        <div class="detail-item">
                                            <div class="detail-label">Price Details</div>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span>Base Price:</span>
                                                <span>₹<?php echo number_format($row['base_price'], 2); ?></span>
                                            </div>
                                            <div class="d-flex justify-content-between mb-2">
                                                <span>Extras Cost:</span>
                                                <span>₹<?php echo number_format($row['extras_cost'], 2); ?></span>
                                            </div>
                                            <div class="d-flex justify-content-between fw-bold">
                                                <span>Total:</span>
                                                <span>₹<?php echo number_format($row['item_total'], 2); ?></span>
                                            </div>
                                        </div>
                                        
                                        <?php
// Ensure $toppings is an array
if (!empty($toppings) && !is_array($toppings)) {
    $toppings = explode(',', $toppings); // Convert comma-separated string to an array
}
?>

<?php if (!empty($toppings) && is_array($toppings)): ?>
    <div class="detail-item">
        <div class="detail-label">Selected Toppings</div>
        <ul class="list-group list-group-flush">
            <?php foreach ($toppings as $topping): ?>
                <li class="list-group-item bg-transparent px-0">
                    <i class="fas fa-check-circle me-2 text-success"></i>
                    <?php echo htmlspecialchars(trim($topping), ENT_QUOTES, 'UTF-8'); ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

                                        <?php if($row['special_design']): ?>
                                        <div class="detail-item">
                                            <div class="detail-label">Special Message</div>
                                            <div class="p-3 bg-light rounded">
                                                "<?php echo htmlspecialchars($row['message_text']); ?>"
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <div class="detail-item">
                                            <div class="detail-label">Added to Cart</div>
                                            <div><?php echo date('F j, Y, g:i a', strtotime($row['created_at'])); ?></div>
                                        </div>
                                        
                                        <?php if($row['updated_at'] != $row['created_at']): ?>
                                        <div>
                                            <div class="detail-label">Last Updated</div>
                                            <div><?php echo date('F j, Y, g:i a', strtotime($row['updated_at'])); ?></div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Edit Modal -->
                        <div class="modal fade" id="editModal<?php echo $row['cart_id']; ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Item</h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post" class="edit-form">
                                            <input type="hidden" name="cart_id" value="<?php echo $row['cart_id']; ?>">
                                            <input type="hidden" name="base_price" value="<?php echo $row['base_price']; ?>">
                                            
                                            <div class="mb-4">
                                                <label for="quantity-<?php echo $row['cart_id']; ?>" class="form-label">Quantity</label>
                                                <div class="input-group">
                                                    <button type="button" class="btn btn-outline-secondary" onclick="decrementQuantity(<?php echo $row['cart_id']; ?>)">
                                                        <i class="fas fa-minus"></i>
                                                    </button>
                                                    <input type="number" class="form-control text-center" id="quantity-<?php echo $row['cart_id']; ?>" 
                                                           name="quantity" value="<?php echo $row['quantity']; ?>" min="1" required>
                                                    <button type="button" class="btn btn-outline-secondary" onclick="incrementQuantity(<?php echo $row['cart_id']; ?>)">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-4">
                                                <label for="message-<?php echo $row['cart_id']; ?>" class="form-label">Custom Message</label>
                                                <textarea class="form-control" id="message-<?php echo $row['cart_id']; ?>" 
                                                          name="message_text" rows="3" placeholder="Enter your special message for the cake..."><?php echo htmlspecialchars($row['message_text']); ?></textarea>
                                                
                                            </div>
                                            
                                            
                                            <div class="d-flex justify-content-end gap-2 mt-4">
                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" name="update" class="btn btn-primary">
                                                    <i class="fas fa-save me-1"></i> Save Changes
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Delete Confirmation Modal -->
                        <div class="modal fade" id="deleteModal<?php echo $row['cart_id']; ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-danger text-white">
                                        <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Confirm Removal</h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center py-4">
                                        <i class="fas fa-trash-alt mb-3" style="font-size: 64px; color: #e74c3c;"></i>
                                        <h4>Are you sure you want to remove this item?</h4>
                                        <p class="text-muted">This action cannot be undone.</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <form method="post">
                                            <input type="hidden" name="cart_id" value="<?php echo $row['cart_id']; ?>">
                                            <button type="submit" name="delete" class="btn btn-danger">
                                                <i class="fas fa-trash-alt me-1"></i> Remove Item
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="cart-summary">
                            <h4 class="mb-4">Order Summary</h4>
                            <div class="summary-row">
                                <div class="summary-label">Items (<?php echo $item_count; ?>)</div>
                                <div class="summary-value">₹<?php echo number_format($cart_total, 2); ?></div>
                            </div>
                            
                            <div class="summary-row">
                                <div class="summary-label">Delivery</div>
                                <div class="summary-value">₹9.99</div>
                            </div>
                            
                            <div class="summary-row">
                                <div class="summary-label">Tax</div>
                                <div class="summary-value">₹<?php echo number_format($cart_total * 0.08, 2); ?></div>
                            </div>
                            
                            <div class="total-row">
                                <div>Total</div>
                                <div>₹<?php echo number_format($cart_total + 9.99 + ($cart_total * 0.08), 2); ?></div>
                            </div>
    
<button id="rzp-button1" class="checkout-btn">
    <i class="fas fa-credit-card me-2"></i> Pay with Razorpay
</button>

<form id="razorpay-form" action="process_payment.php" method="POST" style="display:none;">
    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
    <input type="hidden" name="merchant_order_id" value="<?php echo time(); ?>">
    <input type="hidden" name="amount" value="<?php echo $final_total_paise / 100; ?>"> <!-- Fixed -->
    <input type="hidden" name="primary_cake_id" value="<?php echo $primary_cake_id; ?>">
    <input type="hidden" name="primary_user_id" value="<?php echo $primary_user_id; ?>">
</form>



                            
                            <div class="d-flex justify-content-center mt-3">
                                <a href="cakes.php" class="continue-btn mt-3">
                                    <i class="fas fa-arrow-left me-2" ></i> Continue Shopping
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
              
            <?php else: ?>
                <div class="empty-cart">
                    <div class="empty-cart-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <h3 class="mb-3">Your cart is empty</h3>
                    <p class="text-muted mb-4">Looks like you haven't added any delicious cakes to your cart yet.</p>
                    <a href="index.php" class="btn btn-primary btn-lg px-5 py-3">
                        <i class="fas fa-cookie-bite me-2"></i> Start Shopping
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function showEditForm(cartId) {
            document.getElementById(`item-row-${cartId}`).style.display = 'none';
            document.getElementById(`edit-row-${cartId}`).style.display = 'table-row';
            document.getElementById(`edit-form-${cartId}`).style.display = 'block';
        }
        
        function hideEditForm(cartId) {
            document.getElementById(`item-row-${cartId}`).style.display = 'table-row';
            document.getElementById(`edit-row-${cartId}`).style.display = 'none';
            document.getElementById(`edit-form-${cartId}`).style.display = 'none';
        }
        
        function incrementQuantity(cartId) {
            const inputElement = document.getElementById(`quantity-${cartId}`);
            let value = parseInt(inputElement.value, 10);
            inputElement.value = value + 1;
        }
        
        function decrementQuantity(cartId) {
            const inputElement = document.getElementById(`quantity-${cartId}`);
            let value = parseInt(inputElement.value, 10);
            if (value > 1) {
                inputElement.value = value - 1;
            }
        }
        
       
    </script>


<?php
// Fetch Razorpay credentials from database or config
$default_razorpay_key = "rzp_test_c24H9ZLQiaptXy"; // Default test key
$razorpayKey = !empty($user_razorpay_key) ? $user_razorpay_key : $default_razorpay_key;

// Convert amount to paise (Razorpay requires paise format)
$final_total_paise = intval($final_total * 100);

// Default order description
$orderDescription = "Payment for your order at Cake Shop";
?>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
document.getElementById('rzp-button1').onclick = function(e){
    e.preventDefault(); // Prevent page reload

    var options = {
        "key": "<?php echo htmlspecialchars($razorpayKey); ?>", // Ensures a key is always provided
        "amount": "<?php echo $final_total_paise; ?>", // Amount in paise (1000 paise = ₹10)
        "currency": "INR",
        "name": "<?php echo htmlspecialchars($provider_name); ?>",
        "description": "<?php echo htmlspecialchars($orderDescription); ?>",
        "image": "assets/images/logo.png",
        "handler": function (response){
            document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
            document.getElementById('razorpay-form').submit();
        },
        "prefill": {
            "name": "<?php echo isset($_SESSION['customer_name']) ? htmlspecialchars($_SESSION['customer_name']) : 'Guest'; ?>",
            "email": "<?php echo isset($_SESSION['customer_email']) ? htmlspecialchars($_SESSION['customer_email']) : 'guest@example.com'; ?>",
            "contact": "<?php echo isset($_SESSION['customer_phone']) ? htmlspecialchars($_SESSION['customer_phone']) : '9999999999'; ?>"
        },
        "notes": {
            "items_count": "<?php echo $item_count; ?>",
            "merchant_order_id": "<?php echo time(); ?>" // Unique order ID
        },
        "theme": {
            "color": "#F37254"
        }
    };

    var rzp1 = new Razorpay(options);

    rzp1.on('payment.failed', function (response){
        alert("Payment Failed: " + response.error.description);
    });

    rzp1.open();
}




</script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>