<?php
// Initialize session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include "config.php";

// Check if user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Check if stuffing_id is set
if (!isset($_POST["stuffing_id"])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Missing stuffing ID']);
    exit();
}

// Validate input
if (!is_numeric($_POST["stuffing_id"])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid stuffing ID']);
    exit();
}

// Sanitize input
$stuffing_id = (int)$_POST["stuffing_id"];

// Check if the stuffing belongs to a cake owned by this admin
$check_stmt = $conn->prepare("
    SELECT es.id 
    FROM extra_stuffing es
    JOIN cakes c ON es.cake_id = c.id
    WHERE es.id = ? AND c.user_id = ?
");
$check_stmt->bind_param("ii", $stuffing_id, $_SESSION['user_id']);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows === 0) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Permission denied or stuffing not found']);
    $check_stmt->close();
    exit();
}
$check_stmt->close();

// Delete the stuffing using prepared statement
$stmt = $conn->prepare("DELETE FROM extra_stuffing WHERE id = ?");
$stmt->bind_param("i", $stuffing_id);

if ($stmt->execute()) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'message' => 'Stuffing removed successfully'
    ]);
} else {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $stmt->error
    ]);
}

// Close statement
$stmt->close();
?>