<?php
// Initialize session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include "config.php";

// Check if user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit();
}

// Validate input
if (!isset($_POST["cake_id"]) || !is_numeric($_POST["cake_id"])) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit();
}

// Sanitize input
$cake_id = (int)$_POST["cake_id"];

// Use prepared statement to prevent SQL injection
$stmt = $conn->prepare("SELECT * FROM extra_stuffing WHERE cake_id = ?");
$stmt->bind_param("i", $cake_id);
$stmt->execute();
$result = $stmt->get_result();

$stuffing_options = [];

// Fetch all results
while ($row = $result->fetch_assoc()) {
    $stuffing_options[] = [
        'id' => $row['id'],
        'name' => htmlspecialchars($row['stuffing_name']),
        'price' => number_format((float)$row['stuffing_price'], 2)
    ];
}

// Close statement
$stmt->close();

// Return JSON data
header('Content-Type: application/json');
echo json_encode($stuffing_options);
?>