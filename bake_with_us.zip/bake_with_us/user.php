<?php
session_start();
include "config.php"; // Database connection

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}


if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate a new CSRF token
}
// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Prepare the query to fetch user details
$query = "SELECT username, email, mobile_number, role, created_at, profile_image,address FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $username = $user['username'];
    $email = $user['email'];
    $phone_number = $user['mobile_number'];
    $role = $user['role'];
    $created_at = $user['created_at'];
    $address = $user['address'];
    $profile_image = $user['profile_image'] ?? 'default.png'; // Default image if none is set
} else {
    echo "User not found.";
    exit();
}

$orderQuery = $conn->prepare("SELECT o.*, p.payment_method, p.payment_status, p.payment_date 
                              FROM orders o 
                              LEFT JOIN payments p ON o.order_id = p.order_id
                              WHERE o.user_id = ? AND o.payment_status = 'completed'");
$orderQuery->bind_param("i", $user_id);
$orderQuery->execute();
$orderResult = $orderQuery->get_result();











$cartCount = 0;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Query to count items where order_status is pending
    $query = "SELECT COUNT(*) AS count FROM cart WHERE user_id = ? AND order_status = 'pending'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($cartCount);
    $stmt->fetch();
    $stmt->close();
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    

    <style>
        body { font-family: 'Poppins', sans-serif; padding-top: 80px; background-color:rgb(179, 217, 255); }
        
        
         /* Navbar styling */
         .navbar {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 10px rgb(0, 0, 0);
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 2rem;
            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;
        }
        .nav-link {
            color: #FFD700 !important;
            font-weight: 500;
            transition: all 0.3s ease-in-out;
        }
        .nav-link:hover {
            color: #ffcc33 !important;
            text-shadow: 0px 0px 5px rgba(255, 223, 186, 0.8);
        }
        
     
        @import url('https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap');

        .profile-container {
        background: var(--glass-bg);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        overflow: hidden;
    }

    .profile-image-section {
        border-right: 2px solid rgba(255, 215, 0, 0.2);
        background: rgba(255, 255, 255, 0.6);
    }

    .profile-image {
        border: 3px solid var(--primary-gold);
        box-shadow: 0 4px 15px rgba(255, 215, 0, 0.2);
        transition: var(--transition);
    }

    .profile-image:hover {
        transform: scale(1.05) rotate(2deg);
    }

    .btn-upload {
        background: linear-gradient(45deg, var(--primary-gold), var(--secondary-gold));
        border: none;
        transition: var(--transition);
    }

    .btn-upload:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
    }

    /* Order Cards */
    .order-container {
        background: var(--glass-bg);
        backdrop-filter: blur(8px);
        border: 1px solid rgba(255, 215, 0, 0.1);
        transition: var(--transition);
    }

    .order-container:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.08);
    }

    .section-title {
        position: relative;
        padding-bottom: 1rem;
        font-family: 'Great Vibes', cursive;
    }

    .section-title::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 120px;
        height: 2px;
        background: linear-gradient(to right, transparent, var(--primary-gold), transparent);
    }

    /* Review Cards */
    .review-card {
        background: linear-gradient(145deg, rgba(255, 255, 255, 0.95), rgba(255, 248, 225, 0.9));
        border: none;
        transition: var(--transition);
    }

    .review-card:hover {
        transform: translateY(-5px) rotate(1deg);
    }

    .btn-delete {
        opacity: 0.8;
        transition: var(--transition);
    }

    .btn-delete:hover {
        opacity: 1;
        transform: scale(1.1) rotate(5deg);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .profile-container {
            flex-direction: column;
        }

        .profile-image-section {
            border-right: none;
            border-bottom: 2px solid rgba(255, 215, 0, 0.2);
        }

        .order-container {
            margin-bottom: 1.5rem;
        }
    }

    /* Form Enhancements */
    .form-control:focus {
        border-color: var(--primary-gold);
        box-shadow: 0 0 0 0.25rem rgba(255, 215, 0, 0.25);
    }

    /* Badge Styles */
    .badge {
        letter-spacing: 0.05em;
        font-weight: 500;
    }

    /* Empty State */
    .empty-state img {
        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
    }
    /* Updated Pending Deliveries Section */
.pending-deliveries-container {
    background-color: rgb(255, 51, 51);
    padding: 20px;
    border-radius: 10px;
    margin-top: 100px;
     margin-bottom: 100px;
     margin-left: 100px;
     margin-right: 100px;
}

/* Updated Completed Deliveries Section */
.completed-orders-container {
    background-color:rgb(90, 255, 65);
    padding: 20px;
    border-radius: 10px;
    margin-top: 100px; 
    margin-bottom: 100px;
    margin-left: 100px;
    margin-right: 100px;
}

    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">Bake With Us 🎂</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="cakes.php">Cakes</a></li>
                <li class="nav-item"><a class="nav-link active" href="aboutus.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="user.php">Profile</a></li>
                <li class="nav-item">
    <a class="nav-link" href="cart.php">
        <i class="fas fa-shopping-cart"></i>
        <span id="cartCount" class="badge bg-danger rounded-pill">
            <?php echo $cartCount; ?>
        </span>
    </a>
</li>

                <li class="nav-item">
                    <a href="logout.php" class="btn btn-danger rounded-pill shadow-sm">
                        <i class="fa-solid fa-right-from-bracket "></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-5">
    <div class="row d-flex align-items-center">
        <!-- Left Side - Profile Image & Upload -->
        <div class="col-md-6 text-center">
            <div class="profile-image-section p-4 border rounded bg-light shadow">
                <img src="uploads/<?php echo htmlspecialchars($profile_image); ?>" class="profile-image rounded-circle shadow-lg" alt="Profile Image" width="150" height="150">
                
                <!-- Profile Image Upload Form -->
                <form action="upload_profile.php" method="post" enctype="multipart/form-data" class="mt-3">
                    <input type="file" name="profile_image" class="form-control mb-2">
                    <button type="submit" class="btn btn-warning btn-upload">Upload Image</button>
                </form>
            </div>
        </div>

        <!-- Right Side - User Details -->
        <div class="col-md-6">
            <div class="user-details p-4 border rounded bg-light shadow">
                <h2>Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($phone_number); ?></p>
                <p><strong>Role:</strong> <?php echo htmlspecialchars($role); ?></p>
                <p><strong>Joined On:</strong> <?php echo date("F j, Y", strtotime($created_at)); ?></p>
                <p><strong>Address:</strong> <span id="userAddress"><?php echo htmlspecialchars($address); ?></span></p>

                <!-- Edit Address Button -->
                <button class="btn btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#editAddressModal">
                    <i class="fa-solid fa-pen-to-square me-2"></i>Edit Address
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Address Modal -->
<div class="modal fade" id="editAddressModal" tabindex="-1" aria-labelledby="editAddressModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editAddressModalLabel">Edit Address</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="update_address.php" method="post">
                    <div class="mb-3">
                        <label for="newAddress" class="form-label">Enter New Address:</label>
                        <input type="text" name="address" id="newAddress" class="form-control" value="<?php echo htmlspecialchars($address); ?>">
                    </div>
                    <button type="submit" class="btn btn-success w-100">Save Address</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php 
// Fetch pending deliveries
$user_id = $_SESSION['user_id'];
$pendingOrdersQuery = $conn->prepare("
    SELECT o.*, p.payment_method, p.payment_date                                          
    FROM orders o                                          
    LEFT JOIN payments p ON o.order_id = p.order_id                                         
    WHERE o.user_id = ? AND o.payment_status = 'completed' AND o.delivery_status = 'Pending'
    ORDER BY o.created_at DESC
");
$pendingOrdersQuery->bind_param("i", $user_id);
$pendingOrdersQuery->execute();
$pendingOrderResult = $pendingOrdersQuery->get_result();

// Fetch completed deliveries
$completedOrdersQuery = $conn->prepare("
    SELECT o.*, p.payment_method, p.payment_date                                          
    FROM orders o                                          
    LEFT JOIN payments p ON o.order_id = p.order_id                                         
    WHERE o.user_id = ? AND o.payment_status = 'completed' AND o.delivery_status = 'Completed'
    ORDER BY o.created_at DESC
");
$completedOrdersQuery->bind_param("i", $user_id);
$completedOrdersQuery->execute();
$completedOrderResult = $completedOrdersQuery->get_result();
?>

    <!-- Pending Deliveries Section -->
    <div class="pending-deliveries-container">
    <h2 class="section-title mb-4">Pending Deliveries</h2>
    <?php if ($pendingOrderResult->num_rows > 0): ?>
        <div class="row">
            <?php while ($order = $pendingOrderResult->fetch_assoc()): ?>
                <div class="col-md-6 mb-4">
                    <div class="order-container shadow-sm rounded p-3 h-100">
                        <div class="order-header d-flex justify-content-between align-items-center pb-2 border-bottom">
                            <div>
                                <span class="fs-5 fw-bold">Order #<?php echo htmlspecialchars($order['order_id']); ?></span>
                                <span class="ms-3 text-muted">
                                    <small><?php echo date("F j, Y, g:i a", strtotime($order['created_at'])); ?></small>
                                </span>
                            </div>
                            <span class="badge bg-success rounded-pill px-3 py-2">
                                <?php echo ucfirst(htmlspecialchars($order['payment_status'])); ?>
                            </span>
                        </div>
                        <div class="order-body pt-3">
                            <div class="row mb-3">
                                <div class="col-6">
                                    <p class="mb-1"><i class="bi bi-currency-dollar me-1"></i> <strong>Total:</strong></p>
                                    <p class="fs-5"><?php echo number_format($order['total_amount'], 2); ?> Rs</p>
                                </div>
                                <div class="col-6">
                                    <p class="mb-1"><i class="bi bi-credit-card me-1"></i> <strong>Payment:</strong></p>
                                    <p><?php echo htmlspecialchars($order['payment_method'] ?? 'N/A'); ?></p>
                                </div>
                            </div>
                            
                            <?php if (!empty($order['payment_date'])): ?>
                                <p class="mb-3"><i class="bi bi-calendar-check me-1"></i> <strong>Paid on:</strong> 
                                    <?php echo date("M j, Y", strtotime($order['payment_date'])); ?>
                                </p>
                            <?php endif; ?>

                            <!-- Delivery Status Section -->
                            <p class="mb-3">
                                <i class="bi bi-truck me-1"></i> 
                                <strong>Delivery Status:</strong> 
                                <span class="badge bg-warning rounded-pill px-3 py-2">
                                    Pending
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5 bg-light rounded my-4">
            <img src="assets/images/empty-orders.svg" alt="No Pending Deliveries" class="img-fluid mb-3" style="max-width: 180px;">
            <h3 class="mt-3 fw-bold">No Pending Deliveries</h3>
            <p class="text-muted mb-4">You have no pending deliveries at the moment.</p>
        </div>
    <?php endif; ?>
    </div>
    <!-- Completed Deliveries Section -->
    <div class="completed-orders-container">
    <h2 class="section-title mb-4 mt-5">Completed Deliveries</h2>
    <?php if ($completedOrderResult->num_rows > 0): ?>
        <div class="row">
            <?php while ($order = $completedOrderResult->fetch_assoc()): ?>
                <div class="col-md-6 mb-4">
                    <div class="order-container shadow-sm rounded p-3 h-100">
                        <div class="order-header d-flex justify-content-between align-items-center pb-2 border-bottom">
                            <div>
                                <span class="fs-5 fw-bold">Order #<?php echo htmlspecialchars($order['order_id']); ?></span>
                                <span class="ms-3 text-muted">
                                    <small><?php echo date("F j, Y, g:i a", strtotime($order['created_at'])); ?></small>
                                </span>
                            </div>
                            <span class="badge bg-success rounded-pill px-3 py-2">
                                <?php echo ucfirst(htmlspecialchars($order['payment_status'])); ?>
                            </span>
                        </div>
                        <div class="order-body pt-3">
                            <div class="row mb-3">
                                <div class="col-6">
                                    <p class="mb-1"><i class="bi bi-currency-dollar me-1"></i> <strong>Total:</strong></p>
                                    <p class="fs-5"><?php echo number_format($order['total_amount'], 2); ?> Rs</p>
                                </div>
                                <div class="col-6">
                                    <p class="mb-1"><i class="bi bi-credit-card me-1"></i> <strong>Payment:</strong></p>
                                    <p><?php echo htmlspecialchars($order['payment_method'] ?? 'N/A'); ?></p>
                                </div>
                            </div>
                            
                            <?php if (!empty($order['payment_date'])): ?>
                                <p class="mb-3"><i class="bi bi-calendar-check me-1"></i> <strong>Paid on:</strong> 
                                    <?php echo date("M j, Y", strtotime($order['payment_date'])); ?>
                                </p>
                            <?php endif; ?>

                            <!-- Delivery Status Section -->
                            <p class="mb-3">
                                <i class="bi bi-truck me-1"></i> 
                                <strong>Delivery Status:</strong> 
                                <span class="badge bg-secondary rounded-pill px-3 py-2">
                                    Completed
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
    <?php else: ?>
        <div class="text-center py-5 bg-light rounded my-4">
            <img src="assets/images/empty-orders.svg" alt="No Completed Deliveries" class="img-fluid mb-3" style="max-width: 180px;">
            <h3 class="mt-3 fw-bold">No Completed Deliveries</h3>
            <p class="text-muted mb-4">Your completed orders will appear here once they are delivered.</p>
        </div>
    <?php endif; ?>
</div>


<!-- User Reviews Section -->
<div class="container">
    <h2 class="section-title">Your Classy Reviews ✨</h2>

    <div class="row">
        <?php
        $reviewQuery = "SELECT id, comment, rating FROM reviews WHERE user_id = ?";
        $stmt = $conn->prepare($reviewQuery);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $reviewResult = $stmt->get_result();

        if ($reviewResult->num_rows > 0) {
            while ($review = $reviewResult->fetch_assoc()) {
                echo '
                <div class="col-md-6 mb-3">
                    <div class="card review-card shadow-lg">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div class="review-content">
                                <p class="card-text review-text mb-1">' . htmlspecialchars($review['comment']) . '</p>
                                <div class="rating">' . str_repeat('⭐', $review['rating']) . '</div>
                            </div>
                            <form action="delete_review.php" method="post">
                                <input type="hidden" name="review_id" value="' . $review['id'] . '">
                                <button type="submit" class="btn btn-danger btn-sm btn-delete">❌ Delete</button>
                            </form>
                        </div>
                    </div>
                </div>';
            }
        } else {
            echo "<p class='text-center' style='font-size: 1.5rem; color: #222;'>No reviews found. 😢</p>";
        }
        ?>
    </div>
</div>

<footer class="bg-dark text-light mt-5 py-4">
    <div class="container text-center">
        <p>© 2024 Bake With Us. All rights reserved.</p>
        <p><small>Made with ❤️ for cake lovers everywhere</small></p>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Additional JavaScript functionality if needed
        document.addEventListener('DOMContentLoaded', function() {
            // Any initialization code here
        });
    </script>

</body>
</html>