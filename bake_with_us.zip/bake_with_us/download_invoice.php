<?php
session_start();
require_once 'config.php';
require('fpdf/fpdf.php'); // Include FPDF library

if (!isset($_GET['order_id'])) {
    die("Invalid Request!");
}

$order_id = $_GET['order_id'];

// Fetch order details
$order_query = "SELECT * FROM orders WHERE order_id = ?";
$stmt = $conn->prepare($order_query);
$stmt->bind_param("s", $order_id);
$stmt->execute();
$order_result = $stmt->get_result();
$order = $order_result->fetch_assoc();

if (!$order) {
    die("Order not found!");
}

// Fetch user details
$user_query = "SELECT username, email, mobile_number FROM users WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $order['user_id']);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();

// Fetch order items
$order_items_query = "SELECT oi.quantity, oi.price, c.name AS cake_name 
                      FROM order_items oi 
                      JOIN cakes c ON oi.cake_id = c.id 
                      WHERE oi.order_id = ?";
$stmt = $conn->prepare($order_items_query);
$stmt->bind_param("s", $order_id);
$stmt->execute();
$order_items_result = $stmt->get_result();

// Create a new PDF document
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// **Invoice Header**
$pdf->Cell(190, 10, "Bake_With_Us- Order Invoice", 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(190, 5, "Thank you for your order!", 0, 1, 'C');
$pdf->Ln(10);

// **Customer Details**
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(100, 7, "Customer Details", 0, 1);
$pdf->SetFont('Arial', '', 11);
$pdf->Cell(100, 7, "Name: " . $user['username'], 0, 1);
$pdf->Cell(100, 7, "Email: " . $user['email'], 0, 1);
$pdf->Cell(100, 7, "Mobile: " . $user['mobile_number'], 0, 1);
$pdf->Ln(5);

// **Order Details**
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(100, 7, "Order Details", 0, 1);
$pdf->SetFont('Arial', '', 11);
$pdf->Cell(100, 7, "Order ID: " . $order['order_id'], 0, 1);
$pdf->Cell(100, 7, "Date & Time: " . $order['created_at'], 0, 1);
$pdf->Cell(100, 7, "Payment Status: " . $order['payment_status'], 0, 1);
$pdf->Ln(5);

// **Ordered Items Table**
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(80, 7, "Cake Name", 1);
$pdf->Cell(30, 7, "Quantity", 1);
$pdf->Cell(40, 7, "Price", 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 11);
while ($item = $order_items_result->fetch_assoc()) {
    $pdf->Cell(80, 7, $item['cake_name'], 1);
    $pdf->Cell(30, 7, $item['quantity'], 1, 0, 'C');
    $pdf->Cell(40, 7, "$" . number_format($item['price'], 2), 1, 0, 'R');
    $pdf->Ln();
}

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(110, 7, "Total Amount", 1);
$pdf->Cell(40, 7, "$" . number_format($order['total_amount'], 2), 1, 0, 'R');

$pdf->Ln(15);
$pdf->SetFont('Arial', '', 11);
$pdf->Cell(190, 7, "For any queries, contact us at support@bakewithus.com", 0, 1, 'C');

// **Output PDF**
$pdf->Output("D", "Invoice_$order_id.pdf"); // "D" forces download

$stmt->close();
$conn->close();
?>
