<?php
session_start();
include "config.php"; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim(htmlspecialchars($_POST['username']));
    $email = trim(htmlspecialchars($_POST['email']));
    $mobile = trim(htmlspecialchars($_POST['mobile']));
    $password = trim($_POST['password']);
    $vpassword = trim($_POST['vpassword']);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format!');</script>";
        exit();
    }

    // Validate mobile number (only numbers allowed)
    if (!preg_match('/^[0-9]{10}$/', $mobile)) {
        echo "<script>alert('Invalid mobile number!');</script>";
        exit();
    }

    // Check if passwords match
    if ($password !== $vpassword) {
        echo "<script>alert('Passwords do not match!');</script>";
        exit();
    }

    // Hash the password securely
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Check if email or mobile already exists
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ? OR mobile_number = ?");
    $stmt->bind_param("ss", $email, $mobile);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>alert('Email or Mobile already registered. Please login.'); window.location.href='login.php';</script>";
    } else {
        // Insert new user (default role: user)
        $stmt = $conn->prepare("INSERT INTO users (username, email, mobile_number, password_hash, role) VALUES (?, ?, ?, ?, 'user')");
        $stmt->bind_param("ssss", $username, $email, $mobile, $hashed_password);

        if ($stmt->execute()) {
            echo "<script>alert('Registration Successful! Please Login.'); window.location.href='login.php';</script>";
        } else {
            echo "<script>alert('Error in registration. Try again.');</script>";
        }
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bake With Us - Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Replace existing CSS with this */
        body {
            
    background: url('images/bg4.jpg') no-repeat center center fixed;
    background-size: 100%; /* Ensures the image covers the entire page */
    min-height: 100vh;
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding-top: 70px;


        }

        .navbar-brand {
            font-size: 3rem !important;
            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;
            transition: all 0.3s ease;
        }

        .register-container {
            background: rgb(0, 0, 0);
            backdrop-filter: blur(25px) saturate(200%);
            border: 3px solid rgb(255, 255, 255);
            border-radius: 30px;
            width: 500px; 
            padding: 30px; 
            animation: float 3s ease-in-out infinite;
            margin: 20px auto;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .register-container h1 {
            font-family: 'Great Vibes', cursive;
            font-size: 4rem;
            text-align: center;
            color: rgb(255, 255, 255);
            margin-bottom: 30px;
            position: relative;
        }

        .register-container h1::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: #FFD700;
            border-radius: 2px;
        }

        .form-control {
            padding: 12px 15px 12px 45px; /* Adjusted left padding for icon */
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #fff;
    border-radius: 5px;
    width: 100%;
        }

        .form-control::placeholder {
    color: rgb(255, 255, 255);
    }

.form-control:focus {
    background: rgba(255, 255, 255, 0.3);
    border-color: #FFD700;
    box-shadow: 0 0 10px rgba(255, 215, 0, 0.3);
    }
      

        .input-icon {
            position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255, 255, 255, 0.7);
    font-size: 1rem;
        }

        .btn-register {
            background: linear-gradient(45deg, #FFD700, #ffb400);
            color: #000;
            font-weight: bold;
            padding: 12px;
            border: none;
            border-radius: 8px;
            width: 100%;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4);
        }

        .btn-register::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: rgba(255, 255, 255, 0.1);
            transform: rotate(45deg);
            transition: all 0.5s ease;
        }

        .btn-register:hover::after {
            left: 50%;
            top: 50%;
        }

        .login-link {
            margin-top: 25px;
            color: rgb(255, 255, 255);
            text-align: center;
            font-size: medium;
            font-weight: 600;
        }

        .login-link a {
            position: relative;
            padding-bottom: 2px;
            color: rgb(0, 29, 192);
        }

        .login-link a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 1px;
            background: #FFD700;
            transition: width 0.3s ease;
        }

        .login-link a:hover::after {
            width: 100%;
        }

        .alert-container {
            position: fixed;
            top: 80px;
            left: 50%;
            transform: translateX(-50%);
            width: 90%;
            max-width: 420px;
            z-index: 1000;
        }

        .password-toggle {
            position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: rgba(255, 255, 255, 0.7);
        }

        @media (max-width: 576px) {
            .register-container {
                width: 90%;
                padding: 30px;
            }

            .register-container h1 {
                font-size: 3rem;
            }
        }
        .form-group {
    position: relative;
    margin-bottom: 1.5rem; /* Adjusted spacing */
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: rgba(255, 255, 255, 0.9);
}
    </style>
</head>
<body>
    <div class="alert-container">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg fixed-top shadow">
        <div class="container">
            <a class="navbar-brand fw-bold" href="home.php">Bake With Us 🎂</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav me-3"></ul>
                <div>
                    <a href="login.php" class="btn btn-primary me-2">Login</a>
                    <a href="register.php" class="btn btn-primary">Register</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="register-container">
    <h1>Register</h1>
    <form action="register.php" method="POST">
        <!-- Full Name -->
        <div class="form-group">
            <label for="username">Full Name</label>
            <div class="position-relative">
                <i class="fas fa-user input-icon"></i>
                <input type="text" name="username" class="form-control" placeholder="Enter your full name" required>
            </div>
        </div>

        <!-- Email -->
        <div class="form-group">
            <label for="email">Email</label>
            <div class="position-relative">
                <i class="fas fa-envelope input-icon"></i>
                <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
            </div>
        </div>

        <!-- Mobile Number -->
        <div class="form-group">
            <label for="mobile">Mobile Number</label>
            <div class="position-relative">
                <i class="fas fa-phone input-icon"></i>
                <input type="tel" name="mobile" class="form-control" placeholder="Enter your mobile number" pattern="[0-9]{10}" required>
            </div>
        </div>

        <!-- Password -->
        <div class="form-group">
            <label for="password">Password</label>
            <div class="position-relative">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter password" required>
                <i class="password-toggle fas fa-eye" onclick="togglePassword('password')"></i>
            </div>
        </div>

        <!-- Confirm Password -->
        <div class="form-group">
            <label for="vpassword">Confirm Password</label>
            <div class="position-relative">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" name="vpassword" id="vpassword" class="form-control" placeholder="Re-enter password" required>
                <i class="password-toggle fas fa-eye" onclick="togglePassword('vpassword')"></i>
            </div>
        </div>

        <button type="submit" class="btn btn-register">Register</button>
    </form>
    <div class="login-link">
        Already have an account ? <a href="login.php">Login Here</a>
    </div>
</div>


</body>
</html>

<script>
    function togglePassword(fieldId) {
        const passwordField = document.getElementById(fieldId);
        const toggleIcon = passwordField.nextElementSibling;
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }

    document.querySelectorAll('.form-control').forEach(input => {
        input.addEventListener('focus', () => {
            input.previousElementSibling.style.color = '#FFD700';
        });
        input.addEventListener('blur', () => {
            input.previousElementSibling.style.color = 'rgba(255, 255, 255, 0.7)';
        });
    });
</script>
