<?php
session_start();
require_once 'config.php'; // Include DB connection file

if (!isset($_SESSION['order_id'])) {
    echo "Invalid request!";
    exit;
}

$order_id = $_SESSION['order_id'];
$user_id = $_SESSION['user_id'];

// Fetch order details
$order_query = "SELECT * FROM orders WHERE order_id = ?";
$stmt = $conn->prepare($order_query);
$stmt->bind_param("s", $order_id);
$stmt->execute();
$order_result = $stmt->get_result();
$order = $order_result->fetch_assoc();

// Fetch user details
$user_query = "SELECT username, email, mobile_number FROM users WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();

// Fetch order items
$order_items_query = "SELECT oi.quantity, oi.price, c.name AS cake_name, oi.message_text, oi.special_design, oi.toppings_json 
                      FROM order_items oi 
                      JOIN cakes c ON oi.cake_id = c.id 
                      WHERE oi.order_id = ?";
$stmt = $conn->prepare($order_items_query);
$stmt->bind_param("s", $order_id);
$stmt->execute();
$order_items_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
        }
        .btn-custom {
            background-color: #ff5a5f;
            color: white;
            border-radius: 5px;
            padding: 10px 15px;
            text-decoration: none;
        }
        .btn-custom:hover {
            background-color: #e0484d;
            color: white;
        }
        .order-details {
            font-size: 1.1rem;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card p-4">
        <h2 class="text-center text-success">🎉 Order Confirmed!</h2>
        <p class="text-center">Thank you, <strong><?php echo htmlspecialchars($user['username']); ?></strong>! Your order has been successfully placed.</p>

        <div class="row mt-4">
            <div class="col-md-6">
                <h4 class="mb-3">📦 Order Details</h4>
                <p class="order-details">Order ID: <span class="text-primary"><?php echo htmlspecialchars($order['order_id']); ?></span></p>
                <p class="order-details">Date & Time: <span class="text-muted"><?php echo htmlspecialchars($order['created_at']); ?></span></p>
                <p class="order-details">Total Amount: <span class="text-success"><?php echo number_format($order['total_amount'], 2); ?> Rs</span></p>
                <p class="order-details">Payment Status: <span class="text-warning"><?php echo htmlspecialchars($order['payment_status']); ?></span></p>
            </div>
            <div class="col-md-6">
                <h4 class="mb-3">👤 Customer Details</h4>
                <p class="order-details">Email: <span class="text-muted"><?php echo htmlspecialchars($user['email']); ?></span></p>
                <p class="order-details">Mobile Number: <span class="text-muted"><?php echo htmlspecialchars($user['mobile_number']); ?></span></p>
            </div>
        </div>

        <h4 class="mt-4">🛍️ Ordered Items</h4>
        <table class="table table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Cake Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Special Message</th>
                    <th>Special Design</th>
                    <th>Toppings</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($item = $order_items_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['cake_name']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td><?php echo number_format($item['price'], 2); ?> Rs</td>
                    <td><?php echo htmlspecialchars($item['message_text']); ?></td>
                    <td><?php echo htmlspecialchars($item['special_design']); ?></td>
                    <td><?php echo htmlspecialchars($item['toppings_json']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <h4 class="mt-4">🚀 What's Next?</h4>
        <p>Your order is being processed.</p>

        <div class="text-center">
            <a href="user.php" class="btn btn-custom">🏠 Return to Home</a>
           <!-- <a href="download_invoice.php?order_id=<?php echo $order['order_id']; ?>" class="btn btn-dark">📄 Download Invoice</a> -->
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
