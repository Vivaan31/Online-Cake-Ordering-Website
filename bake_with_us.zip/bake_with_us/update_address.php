<?php
session_start();
require 'config.php'; // Include database connection

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['address'])) {
    $new_address = trim($_POST['address']);

    // Validate input
    if (empty($new_address)) {
        $_SESSION['error'] = "Address cannot be empty!";
        header("Location: user.php");
        exit();
    }

    // Update query with prepared statement
    $stmt = $conn->prepare("UPDATE users SET address = ? WHERE id = ?");
    $stmt->bind_param("si", $new_address, $user_id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Address updated successfully!";
    } else {
        $_SESSION['error'] = "Failed to update address. Try again!";
    }

    $stmt->close();
    $conn->close();

    header("Location: user.php");
    exit();
}
?>
