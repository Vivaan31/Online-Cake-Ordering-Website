<?php
session_start();
include "config.php"; // Include database connection



$cake_id = isset($_GET['cake_id']) ? intval($_GET['cake_id']) : 0;

if ($cake_id > 0) {
    $stmt = $conn->prepare("SELECT id, stuffing_name, stuffing_price FROM extra_stuffing WHERE cake_id = ?");
    $stmt->bind_param("i", $cake_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $stuffings = [];
    while ($row = $result->fetch_assoc()) {
        $stuffings[] = $row;
    }

    echo json_encode($stuffings);
    $stmt->close();
} else {
    echo json_encode(["error" => "Invalid cake_id"]);
}

$conn->close();

?>