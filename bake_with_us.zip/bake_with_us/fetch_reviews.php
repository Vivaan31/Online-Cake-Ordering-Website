<?php
include 'config.php'; // Include your DB connection file

if (isset($_GET['cake_id'])) {
    $cake_id = intval($_GET['cake_id']);
    $sql = "SELECT users.username, reviews.rating, reviews.comment FROM reviews 
            JOIN users ON reviews.user_id = users.id 
            WHERE reviews.cake_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cake_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $reviews = [];
    while ($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }

    echo json_encode($reviews);
}
?>
