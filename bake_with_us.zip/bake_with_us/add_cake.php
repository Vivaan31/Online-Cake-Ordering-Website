<?php
session_start();
include "config.php"; // Database connection

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Handle Cake Deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_cake"])) {
    $cake_id = (int)$_POST["cake_id"]; // Cast to integer for security
    $stmt = $conn->prepare("DELETE FROM cakes WHERE id = ?");
    $stmt->bind_param("i", $cake_id);
    $stmt->execute();
    $stmt->close();
    echo "<script>alert('Cake removed successfully!'); window.location.href='add_cake.php';</script>";
}

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_cake"])) {
    $name = htmlspecialchars($_POST["name"]);
    $price = (float)$_POST["price"];
    $description = htmlspecialchars($_POST["description"]);
    $type = htmlspecialchars($_POST["type"]);
    $weight = htmlspecialchars($_POST["weight"]); // Capture weight input
    $user_id = (int)$_SESSION['user_id']; // Get the logged-in admin's user ID

    // Allowed weight options
    $allowed_weights = ["0.5 kg", "1 kg", "2 kg", "3 kg", "4 kg", "5 kg"];

    // Validate weight selection
    if (!in_array($weight, $allowed_weights)) {
        echo "<script>alert('Error: Invalid weight selected.');</script>";
        exit;
    }

    // Handle Image Upload
    $image_name = "";
    if(isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $allowed = ["jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png"];
        $filename = $_FILES["image"]["name"];
        $filetype = $_FILES["image"]["type"];
        $filesize = $_FILES["image"]["size"];

        // Verify file extension
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        if(!array_key_exists($ext, $allowed)) {
            echo "<script>alert('Error: Please select a valid file format.');</script>";
        } else {
            // Verify file size - 5MB maximum
            $maxsize = 5 * 1024 * 1024;
            if($filesize > $maxsize) {
                echo "<script>alert('Error: File size is larger than the allowed limit.');</script>";
            } else {
                // Verify MIME type of the file
                if(in_array($filetype, $allowed)) {
                    // Generate unique filename
                    $image_name = uniqid() . "_" . $filename;
                    $target_dir = "uploads/";
                    $target_file = $target_dir . $image_name;
                    
                    // Create directory if it doesn't exist
                    if (!file_exists($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    
                    if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                        // File uploaded successfully
                    } else {
                        echo "<script>alert('Error: There was a problem uploading your file.');</script>";
                        $image_name = "";
                    }
                } else {
                    echo "<script>alert('Error: There was a problem with your upload.');</script>";
                    $image_name = "";
                }
            }
        }
    }

    // Insert Data into Database using prepared statement
    if(!empty($image_name)) {
        $stmt = $conn->prepare("INSERT INTO cakes (name, image, price, description, type, weight, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdsssi", $name, $image_name, $price, $description, $type, $weight, $user_id);
        
        if ($stmt->execute()) {
            echo "<script>alert('Cake added successfully!'); window.location.href='add_cake.php';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Error: Please upload a valid image.');</script>";
    }
}

// Fetch Cakes from Database
$cakes = $conn->query("SELECT * FROM cakes ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bake With Us - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            color: #fff; 
            background-color: #333;
            padding-top: 80px; /* Account for fixed navbar */
        }
        .navbar { 
            
            background: rgba(0, 0, 0, 0.7); 
            backdrop-filter: blur(10px); 
        }
        .navbar-brand {     font-family: 'Montserrat', sans-serif;

            font-size: 2rem; 
            color: #FFD700 !important; 
        }
        .nav-link { 
            color: #FFD700 !important; 
            font-weight: 500; 
            transition: all 0.3s ease-in-out; 
        }
        .nav-link:hover { 
            color: #ffcc33 !important; 
            text-shadow: 0px 0px 5px rgba(255, 223, 186, 0.8); 
        }
        .card { 
            background-color: #444; 
            color: white; 
            border: 1px solid #555;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        .cake-container { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 20px; 
            justify-content: center; 
        }
        .cake-card { 
            width: 20rem;
            margin-bottom: 20px;
        }
        .modal-content { 
            background-color: #444;
            color: white;
        }
        .btn-primary {
            background-color: #4e8cff;
            border: none;
        }
        .btn-danger { 
            background-color: #c82333; 
            border: none; 
        }
        .btn-warning {
            color: #000;
        }
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
        .list-group-item {
            background-color: #555;
            color: white;
            border-color: #666;
        }
        .form-control, .form-select {
            background-color: #555;
            color: white;
            border-color: #666;
        }
        .form-control:focus, .form-select:focus {
            background-color: #555;
            color: white;
            border-color: #4e8cff;
            box-shadow: 0 0 0 0.25rem rgba(78, 140, 255, 0.25);
        }
        .form-control::placeholder {
            color: #ccc;
        }
        .page-header {
            border-bottom: 2px solid #FFD700;
            padding-bottom: 10px;
            margin-bottom: 30px;
        }
        .btn-close {
            filter: invert(1);
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">Bake With Us 🎂</a>
        <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="admin.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="add_cake.php">Manage Cakes</a></li>
                <li class="nav-item"><a class="nav-link" href="orders.php">Orders</a></li>
                
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container">
        <h2 class="text-center page-header">Cake Management</h2>
        
        <form class="card p-4 shadow mb-5" action="" method="POST" enctype="multipart/form-data">
            <h3 class="mb-4">Add a New Cake</h3>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Cake Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Price (₹)</label>
                    <input type="number" name="price" class="form-control" step="0.01" min="0" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Cake Image</label>
                <input type="file" name="image" class="form-control" accept="image/*" required>
                <div class="form-text text-light">Maximum file size: 5MB. Supported formats: JPG, PNG, GIF</div>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3" required></textarea>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Type</label>
                    <select name="type" class="form-select" required>
                        <option value="">Select cake type</option>
                        <option value="Classic">Classic</option>
                        <option value="Seasonal">Seasonal</option>
                        <option value="Premium">Premium</option>
                        <option value="Custom">Custom</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Weight</label>
                    <select name="weight" class="form-select" required>
                        <option value="">Select cake weight</option>
                        <option value="0.5 kg">0.5 kg</option>
                        <option value="1 kg">1 kg</option>
                        <option value="2 kg">2 kg</option>
                        <option value="3 kg">3 kg</option>
                        
                    </select>
                </div>
            </div>
            
            <button type="submit" name="add_cake" class="btn btn-primary btn-lg">Add Cake</button>
        </form>

        <h3 class="text-center mb-4">Available Cakes</h3>
        
        <div class="cake-container">
            <?php if($cakes->num_rows > 0): ?>
                <?php while ($cake = $cakes->fetch_assoc()): ?>
                <div class="card cake-card">
                    <img src="uploads/<?php echo htmlspecialchars($cake["image"]); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($cake["name"]); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($cake["name"]); ?></h5>
                        <p class="card-text"><strong>Price:</strong> ₹<?php echo number_format($cake["price"], 2); ?></p>
                        <p class="card-text"><strong>Weight:</strong> <?php echo !empty($cake["weight"]) ? htmlspecialchars($cake["weight"]) : "Not specified"; ?></p>
                        <p class="card-text"><strong>Type:</strong> <?php echo htmlspecialchars($cake["type"]); ?></p>
                        <p class="card-text"><?php echo htmlspecialchars(substr($cake["description"], 0, 100)) . (strlen($cake["description"]) > 100 ? '...' : ''); ?></p>
                        
                        <div class="d-flex justify-content-between mt-3">
                            <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this cake?');">
                                <input type="hidden" name="cake_id" value="<?php echo $cake['id']; ?>">
                                <button type="submit" name="delete_cake" class="btn btn-danger">Delete</button>
                            </form>
                            <button class="btn btn-warning add-stuffing-btn" data-cakeid="<?php echo $cake['id']; ?>" data-bs-toggle="modal" data-bs-target="#stuffingModal">
                                Manage Stuffing
                            </button>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="alert alert-info w-100 text-center" role="alert">
                    No cakes available. Add your first cake using the form above.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Stuffing Modal -->
    <div class="modal fade" id="stuffingModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Manage Cake Stuffing</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <h6>Current Stuffing Options</h6>
                    <ul id="stuffing-list" class="list-group mb-4">
                        <li class="list-group-item text-center" id="loading-stuffing">Loading stuffing options...</li>
                        <li class="list-group-item text-center" id="no-stuffing" style="display:none;">No stuffing options available</li>
                    </ul>

                    <h6>Add New Stuffing</h6>
                    <form id="add-stuffing-form">
                        <input type="hidden" id="cake_id" name="cake_id">
                        <div class="mb-3">
                            <label class="form-label">Stuffing Name</label>
                            <input type="text" name="stuffing_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price (₹)</label>
                            <input type="number" name="stuffing_price" class="form-control" step="0.01" min="0" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Add Stuffing Option</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        // Handle stuffing modal opening
        $(".add-stuffing-btn").click(function() {
            let cake_id = $(this).data("cakeid");
            $("#cake_id").val(cake_id);
            $("#loading-stuffing").show();
            $("#no-stuffing").hide();
            $("#stuffing-list li:not(#loading-stuffing, #no-stuffing)").remove();
            
            // Fetch current stuffing data via AJAX
            $.ajax({
                url: "fetch_stuffing.php",
                type: "POST",
                data: { cake_id: cake_id },
                dataType: "json",
                success: function(response) {
                    $("#loading-stuffing").hide();
                    
                    if (response.length === 0) {
                        $("#no-stuffing").show();
                    } else {
                        response.forEach(function(stuffing) {
                            addStuffingToList(stuffing);
                        });
                    }
                },
                error: function() {
                    $("#loading-stuffing").hide();
                    $("#no-stuffing").show().text("Error loading stuffing options");
                }
            });
        });

        // Add stuffing submission
        $("#add-stuffing-form").submit(function(e) {
            e.preventDefault();
            
            $.ajax({
                url: "add_stuffing.php",
                type: "POST",
                data: $(this).serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.success) {
                        $("#no-stuffing").hide();
                        addStuffingToList(response.stuffing);
                        $("#add-stuffing-form")[0].reset();
                    } else {
                        alert("Error: " + response.message);
                    }
                },
                error: function() {
                    alert("An error occurred while adding stuffing");
                }
            });
        });

        // Handle stuffing deletion
        $(document).on("click", ".delete-stuffing", function() {
            if (confirm("Are you sure you want to delete this stuffing option?")) {
                let stuffing_id = $(this).data("stuffingid");
                let listItem = $(this).closest("li");
                
                $.ajax({
                    url: "delete_stuffing.php",
                    type: "POST",
                    data: { stuffing_id: stuffing_id },
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            listItem.fadeOut(300, function() {
                                $(this).remove();
                                if ($("#stuffing-list li:not(#loading-stuffing, #no-stuffing)").length === 0) {
                                    $("#no-stuffing").show();
                                }
                            });
                        } else {
                            alert("Error: " + response.message);
                        }
                    },
                    error: function() {
                        alert("An error occurred while deleting stuffing");
                    }
                });
            }
        });

        // Helper function to add stuffing to the list
        function addStuffingToList(stuffing) {
            $("#stuffing-list").append(
                `<li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <strong>${stuffing.name}</strong>
                        <span class="ms-3">₹${parseFloat(stuffing.price).toFixed(2)}</span>
                    </div>
                    <button type="button" class="btn btn-sm btn-danger delete-stuffing" data-stuffingid="${stuffing.id}">
                        Remove
                    </button>
                </li>`
            );
        }
    });
    </script>

</body>
</html>