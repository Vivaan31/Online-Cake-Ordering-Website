<?php
session_start();
include "config.php"; // Database connection

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}
class CartModel {
    private $db;
    
    /**
     * Constructor - initialize database connection
     */
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * Add item to cart
     * 
     * @param int $userId User ID
     * @param int $cakeId Cake ID
     * @param int $quantity Quantity
     * @param array $options Additional options (message, design, toppings)
     * @return array Response with status and message
     */
    public function addToCart($userId, $cakeId, $quantity = 1, $options = []) {
        try {
            // Validate inputs
            if (!$cakeId) {
                throw new Exception("Invalid cake selection");
            }
            
            $quantity = max(1, intval($quantity));
            
            // Extract options
            $messageText = isset($options['message_text']) ? trim($options['message_text']) : '';
            $specialDesign = isset($options['special_design']) ? trim($options['special_design']) : '';
            $toppings = isset($options['toppings']) ? $options['toppings'] : [];
            
            // Get cake details
            $cake = $this->getCakeDetails($cakeId);
            if (!$cake) {
                throw new Exception("Cake not found");
            }
            
            // Calculate costs
            $pricing = $this->calculatePrice($cake['price'], $messageText, $toppings);
            $itemTotal = ($pricing['base_price'] * $quantity) + $pricing['extras_cost'];
            
            // Insert into database
            $stmt = $this->db->prepare("INSERT INTO cart 
                (user_id, cake_id, quantity, message_text, special_design, toppings_json, 
                base_price, extras_cost, item_total, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            
            $toppingsJson = json_encode($pricing['topping_details']);
            
            $stmt->bind_param("iiisssdd", 
                $userId,
                $cakeId,
                $quantity,
                $messageText,
                $specialDesign,
                $toppingsJson,
                $pricing['base_price'],
                $pricing['extras_cost'],
                $itemTotal
            );
            
            $result = $stmt->execute();
            $cartItemId = $stmt->insert_id;
            
            if (!$result) {
                throw new Exception("Failed to add item to cart");
            }
            
            return [
                'success' => true,
                'message' => 'Item added to cart successfully',
                'item_id' => $cartItemId,
                'item_total' => $itemTotal
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get cake details by ID
     * 
     * @param int $cakeId Cake ID
     * @return array|false Cake details or false if not found
     */
    private function getCakeDetails($cakeId) {
        $stmt = $this->db->prepare("SELECT id, name, price,image FROM cakes WHERE id = ?");
        $stmt->bind_param("i", $cakeId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return false;
        }
        
        return $result->fetch_assoc();
    }
    
    /**
     * Calculate price details for cart item
     * 
     * @param float $basePrice Base cake price
     * @param string $messageText Custom message
     * @param array $toppingNames Array of topping names
     * @return array Price breakdown
     */
    private function calculatePrice($basePrice, $messageText, $toppingNames) {
        $extrasCost = 0;
        $toppingDetails = [];
        
        // Add message cost if applicable
        if (!empty($messageText)) {
            $extrasCost += 3.00; // $3 for custom message
        }
        
        // Calculate toppings cost
        if (!empty($toppingNames)) {
            // Create placeholders for SQL query
            $placeholders = str_repeat("?,", count($toppingNames) - 1) . "?";
            $query = "SELECT name, price FROM  WHERE name IN ($placeholders) AND active = 1";
            
            $stmt = $this->db->prepare($query);
            
            // Create type string for bind_param
            $types = str_repeat("s", count($toppingNames));
            $bindParams = array($types);
            
            // Add each topping name as a reference
            foreach ($toppingNames as &$name) {
                $bindParams[] = &$name;
            }
            
            // Bind parameters dynamically
            call_user_func_array([$stmt, 'bind_param'], $bindParams);
            
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($topping = $result->fetch_assoc()) {
                $extrasCost += $topping['price'];
                $toppingDetails[] = [
                    'name' => $topping['name'],
                    'price' => $topping['price']
                ];
            }
        }
        
        return [
            'base_price' => $basePrice,
            'extras_cost' => $extrasCost,
            'topping_details' => $toppingDetails
        ];
    }
    
    /**
     * Get user's cart items
     * 
     * @param int $userId User ID
     * @return array Cart items
     */
    public function getCartItems($userId) {
        $stmt = $this->db->prepare("
            SELECT c.*, 
                   ck.name as cake_name, 
                   ck.image as cake_image
            FROM cart c
            JOIN cakes ck ON c.cake_id = ck.id
            WHERE c.user_id = ?
            ORDER BY c.created_at DESC
        ");
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $items = [];
        $totalAmount = 0;
        
        while ($item = $result->fetch_assoc()) {
            // Decode JSON toppings
            $item['toppings'] = json_decode($item['toppings_json'], true);
            unset($item['toppings_json']);
            
            $items[] = $item;
            $totalAmount += $item['item_total'];
        }
        
        return [
            'items' => $items,
            'total_amount' => $totalAmount,
            'item_count' => count($items)
        ];
    }
    
    /**
     * Update cart item quantity
     * 
     * @param int $itemId Cart item ID
     * @param int $quantity New quantity
     * @param int $userId User ID for verification
     * @return array Response with status and message
     */
    public function updateQuantity($itemId, $quantity, $userId) {
        try {
            $quantity = max(1, intval($quantity));
            
            // First get the current item to recalculate total
            $stmt = $this->db->prepare("
                SELECT base_price, extras_cost 
                FROM cart 
                WHERE id = ? AND user_id = ?
            ");
            
            $stmt->bind_param("ii", $itemId, $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception("Cart item not found");
            }
            
            $item = $result->fetch_assoc();
            $itemTotal = ($item['base_price'] * $quantity) + $item['extras_cost'];
            
            // Update the quantity and item total
            $updateStmt = $this->db->prepare("
                UPDATE cart 
                SET quantity = ?, item_total = ? 
                WHERE id = ? AND user_id = ?
            ");
            
            $updateStmt->bind_param("idii", 
                $quantity,
                $itemTotal,
                $itemId,
                $userId
            );
            
            $result = $updateStmt->execute();
            
            if (!$result) {
                throw new Exception("Failed to update cart");
            }
            
            return [
                'success' => true,
                'message' => 'Cart updated successfully',
                'new_quantity' => $quantity,
                'new_total' => $itemTotal
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Remove item from cart
     * 
     * @param int $itemId Cart item ID
     * @param int $userId User ID for verification
     * @return array Response with status and message
     */
    public function removeItem($itemId, $userId) {
        try {
            $stmt = $this->db->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $itemId, $userId);
            $result = $stmt->execute();
            
            if (!$result || $stmt->affected_rows === 0) {
                throw new Exception("Item not found or already removed");
            }
            
            return [
                'success' => true,
                'message' => 'Item removed from cart'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Clear entire cart for a user
     * 
     * @param int $userId User ID
     * @return array Response with status and message
     */
    public function clearCart($userId) {
        try {
            $stmt = $this->db->prepare("DELETE FROM cart WHERE user_id = ?");
            $stmt->bind_param("i", $userId);
            $result = $stmt->execute();
            
            if (!$result) {
                throw new Exception("Failed to clear cart");
            }
            
            return [
                'success' => true,
                'message' => 'Cart cleared successfully'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get cart summary (count and total amount)
     * 
     * @param int $userId User ID
     * @return array Cart summary
     */
    public function getCartSummary($userId) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as item_count, SUM(item_total) as total_amount
            FROM cart
            WHERE user_id = ?
        ");
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $summary = $result->fetch_assoc();
        
        return [
            'item_count' => (int)$summary['item_count'],
            'total_amount' => (float)$summary['total_amount'] ?: 0
        ];
    }
}

$cartCount = 0;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Query to count items where order_status is pending
    $query = "SELECT COUNT(*) AS count FROM cart WHERE user_id = ? AND order_status = 'pending'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($cartCount);
    $stmt->fetch();
    $stmt->close();
}

// Fetch cakes with average ratings and review counts
$sql = "SELECT cakes.*, 
               COALESCE(AVG(reviews.rating), 0) AS avg_rating, 
               COUNT(reviews.id) AS total_reviews
        FROM cakes
        LEFT JOIN reviews ON cakes.id = reviews.cake_id
        GROUP BY cakes.id";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bake With Us - Exquisite Cakes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">


   <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            padding-top: 80px; 
            background-color:rgb(228, 140, 255); 
        }
        
        /* Navbar styling */
        .navbar {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 10px rgba(255, 223, 186, 0.3);
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 2rem;
            font-family: 'Great Vibes', cursive;
            color: #FFD700 !important;
        }
        .nav-link {
            color: #FFD700 !important;
            font-weight: 500;
            transition: all 0.3s ease-in-out;
        }
        .nav-link:hover {
            color: #ffcc33 !important;
            text-shadow: 0px 0px 5px rgba(255, 223, 186, 0.8);
        }
        
        /* Cake card styling */
        .cake-box { 
            border: 1px solid #ddd; 
            padding: 15px; 
            border-radius: 10px; 
            background: #fff; 
            transition: 0.3s ease-in-out;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .cake-box:hover { 
            transform: translateY(-5px); 
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1); 
        }
        .cake-image { 
            width: 100%; 
            height: 220px; 
            background-size: cover; 
            background-position: center; 
            border-radius: 8px; 
            position: relative; 
            margin-bottom: 15px;
        }
        .cake-price { 
            position: absolute; 
            bottom: 10px; 
            right: 10px; 
            background: rgba(0, 0, 0, 0.7); 
            color: #fff; 
            padding: 5px 10px; 
            border-radius: 5px;
            font-weight: bold;
        }
        .cake-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }
        .cake-actions {
            margin-top: auto;
        }
        .cake-actions button { 
            margin: 5px;
            transition: all 0.2s ease;
        }
        .cake-actions button:hover {
            transform: scale(1.05);
        }
        
        /* Star rating system */
        .star-rating {
            font-size: 1.5rem;
            color: #ccc;
            cursor: pointer;
        }
        .star-rating .star:hover,
        .star-rating .star.selected {
            color: #FFD700;
        }
        
        /* Review modal styling */
        .modal-content {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(15px);
            border-radius: 12px;
            box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.3);
            border: none;
        }
        .modal-header {
            border-bottom: none;
            padding: 20px 25px;
        }
        .modal-title {
            font-weight: bold;
            color: #333;
        }
        .modal-body {
            padding: 20px 25px;
        }
        
        /* Review cards */
        .review-card {
            background: rgba(248, 249, 250, 0.9);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .review-card:hover {
            transform: translateY(-3px);
            box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.15);
        }
        .review-author {
            font-weight: bold;
            color: #333;
        }
        
        /* Loading animation */
        .loader {
            width: 40px;
            height: 40px;
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-top: 4px solid #FFD700;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Cart customization */
        .topping-option {
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .topping-option.selected {
            background-color: #198754;
            color: white;
            border-color: #198754;
        }
        .total-price {
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }
        
        /* Title section */
        .section-title {
            font-size: 50px;
            font-weight:800;
            position:relative;
            margin-bottom: 40px;
            padding-bottom: 10px;
        }
        .section-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 450px;
            height: 3px;
            background: linear-gradient(to right, #FFD700, #FFA500);
        }
        
        /* Quantity selector */
        .quantity-selector {
            display: flex;
            align-items: center;
            max-width: 120px;
            margin: 0 auto;
        }
        .quantity-btn {
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            cursor: pointer;
        }
        .quantity-input {
            width: 40px;
            text-align: center;
            border: 1px solid #dee2e6;
            border-left: none;
            border-right: none;
        }
    </style>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

</head>
<body>
<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">Bake With Us 🎂</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="cakes.php">Cakes</a></li>
                <li class="nav-item"><a class="nav-link active" href="aboutus.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="user.php">Profile</a></li>
                <li class="nav-item">
    <a class="nav-link" href="cart.php">
        <i class="fas fa-shopping-cart"></i>
        <span id="cartCountx" class="badge bg-danger rounded-pill">
            <?php echo $cartCount; ?>
        </span>
    </a>
</li>

                <li class="nav-item">
                    <a href="logout.php" class="btn btn-danger rounded-pill shadow-sm">
                        <i class="fa-solid fa-right-from-bracket "></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <!-- Cake Display Section -->
    <div class="container py-5">
        <h2 class="text-center section-title"><b>Our Signature Cakes</b></h2>
        
      
        <div class="row" id="cakesContainer">
            <?php if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) { ?>
                    <div class="col-lg-4 col-md-6 mb-4 cake-item" 
                         data-price="<?php echo $row['price']; ?>"
                         data-rating="<?php echo $row['avg_rating']; ?>"
                         data-type="<?php echo htmlspecialchars($row['type']); ?>">
                        <div class="cake-box">
                            <div class="cake-image" style="background-image: url('uploads/<?php echo htmlspecialchars($row['image']); ?>');">
                                <div class="cake-price">₹<?php echo number_format($row['price'], 2); ?></div>
                            </div>
                            <div class="cake-content">
                                <h3 class="h5 mb-2"><?php echo htmlspecialchars($row['name']); ?></h3>
                                
                                <p class="small text-muted mb-3"><?php echo htmlspecialchars($row['description']); ?></p>
                                
                                <div class="d-flex justify-content-between mb-3">
                                    <p class="mb-0"><i class="fas fa-birthday-cake me-1"></i> <?php echo htmlspecialchars($row['type']); ?></p>
                                    <p class="mb-0"><i class="fas fa-weight-hanging me-1"></i> <?php echo htmlspecialchars($row['weight']); ?></p>
                                </div>
                                
                                <!-- Star Rating -->
                                <div class="text-warning mb-3">
                                    <?php 
                                    $avg_rating = round($row['avg_rating'], 1);
                                    $total_reviews = $row['total_reviews'];
                                    
                                    for ($i = 1; $i <= 5; $i++) {
                                        if ($i <= $avg_rating) {
                                            echo '<i class="fas fa-star"></i>';
                                        } elseif ($i - 0.5 <= $avg_rating) {
                                            echo '<i class="fas fa-star-half-alt"></i>';
                                        } else {
                                            echo '<i class="far fa-star"></i>';
                                        }
                                    }
                                    ?>
                                    <span class="ms-1 text-muted small"><?php echo number_format($avg_rating, 1); ?> (<?php echo $total_reviews; ?>)</span>
                                </div>
                                
                                <div class="cake-actions">
                                    <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#reviewModal"
                                            onclick="setCakeId(<?php echo $row['id']; ?>)">
                                        <i class="fas fa-pen"></i> Write Review
                                    </button>
                                    <button class="btn btn-sm btn-outline-info" onclick="fetchReviews(<?php echo $row['id']; ?>)" 
                                            data-bs-toggle="modal" data-bs-target="#reviewsModal">
                                        <i class="fas fa-comments"></i> View Reviews
                                    </button>
                                    <button class="btn btn-sm btn-success mt-2 w-100 h-50" 
                                    onclick="prepareCartModal(<?php echo $row['id']; ?>, 
                          '<?php echo addslashes($row['name']); ?>', 
                          <?php echo $row['price']; ?>, 
                          'uploads/<?php echo addslashes($row['image']); ?>')" 
                                            data-bs-toggle="modal" data-bs-target="#cartModal">
                                        <i class="fas fa-shopping-cart"></i> Add to Cart
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
            } else { 
                echo "<div class='col-12 text-center py-5'><p class='text-muted'>No cakes available at the moment. Please check back later.</p></div>"; 
            }
            ?>
        </div>
        
        <!-- No Results Message (initially hidden) -->
        <div id="noResultsMessage" class="text-center py-4 d-none">
            <i class="fas fa-search fa-3x text-muted mb-3"></i>
            <p class="lead">No cakes match your search criteria</p>
            <button class="btn btn-outline-primary mt-2" onclick="resetFilters()">Clear Filters</button>
        </div>
    </div>

    <!-- Cart Modal -->
    <div class="modal fade" id="cartModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content shadow-lg rounded-4">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-shopping-cart me-2"></i>Customize Your Order</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <form id="cartForm">
                        <input type="hidden" id="cakeId" name="cake_id">
                        <input type="hidden" id="cakePrice" name="cake_price">

                        <div class="row mb-4 align-items-center">
                            <div class="col-md-5">
                                <img src="" class="img-fluid rounded shadow-sm" id="cakeImage" alt="Cake">
                            </div>
                            <div class="col-md-7">
                                <h4 id="cakeName" class="fw-bold text-dark mb-2"></h4>
                                <p id="cakeBasePrice" class="text-muted"></p>
                                <p class="small text-muted"><i class="fas fa-info-circle me-1"></i> Customize your order with special messages and toppings.</p>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="messageText" class="form-label fw-semibold"><i class="fas fa-pen-fancy me-2"></i>Message on Cake</label>
                            <input type="text" class="form-control" id="messageText" name="message_text" placeholder="Happy Birthday, Alex!" maxlength="50">
                            <div class="form-text">Up to 50 characters. Add ₹3 for custom message.</div>
                        </div>

                        <div class="mb-4">
    <label class="form-label fw-semibold">
        <i class="fas fa-cookie me-2"></i>Extra Toppings
    </label>
    <div id="toppingsContainer" class="d-flex flex-wrap gap-2">
        <!-- Toppings will be inserted dynamically here -->
    </div>
</div>

                        <div class="mb-4">
                            <label for="specialDesign" class="form-label fw-semibold"><i class="fas fa-paint-brush me-2"></i>Special Design Requests</label>
                            <textarea class="form-control" id="specialDesign" name="special_design" rows="2" placeholder="Describe any special decorations you'd like..."></textarea>
                        </div>

                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <label for="quantity" class="form-label fw-semibold"><i class="fas fa-layer-group me-2"></i>Quantity</label>
                                <div class="quantity-selector mx-0">
                                    <button type="button" class="quantity-btn" onclick="updateQuantity(-1)">-</button>
                                    <input type="text" id="quantity" name="quantity" class="quantity-input" value="1" readonly>
                                    <button type="button" class="quantity-btn" onclick="updateQuantity(1)">+</button>
                                </div>
                            </div>
                            <div class="col-md-6 text-end">
                                <div class="d-flex flex-column align-items-end">
                                    <div class="text-muted small mb-1">Base Price: <span id="basePriceDisplay">₹0.00</span></div>
                                    <div class="text-muted small mb-1">Extras: <span id="extrasCostDisplay">₹0.00</span></div>
                                    <h4 class="total-price fw-bold text-success">Total: <span id="totalPrice">₹0.00</span></h4>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="addToCart()">
                        <i class="fas fa-shopping-cart me-1"></i> Add to Cart
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Reviews Display Modal -->
    <div class="modal fade" id="reviewsModal" tabindex="-1" aria-labelledby="reviewsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reviewsModalLabel"><i class="fas fa-star me-2 text-warning"></i>Customer Reviews</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="reviewStats" class="text-center mb-4 d-none">
                        <div class="display-4 fw-bold text-warning" id="avgRatingDisplay">4.5</div>
                        <div class="text-muted small" id="totalReviewsDisplay">Based on 24 reviews</div>
                        <div class="rating-bars mt-3"></div>
                    </div>
                    <div id="reviewsContainer" class="text-center">
                        <div class="loader"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Write Review Modal -->
    <div class="modal fade" id="reviewModal" tabindex="-1" aria-labelledby="reviewModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reviewModalLabel"><i class="fas fa-pen me-2"></i>Share Your Experience</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="reviewForm">
                        <div class="mb-4 text-center">
                            <label class="form-label">Your Rating</label>
                            <div class="star-rating">
                                <span class="star" data-value="1"><i class="far fa-star"></i></span>
                                <span class="star" data-value="2"><i class="far fa-star"></i></span>
                                <span class="star" data-value="3"><i class="far fa-star"></i></span>
                                <span class="star" data-value="4"><i class="far fa-star"></i></span>
                                <span class="star" data-value="5"><i class="far fa-star"></i></span>
                            </div>
                            <input type="hidden" id="rating" name="rating" required>
                        </div>
                        <div class="mb-3">
                            <label for="comment" class="form-label">Your Review</label>
                            <textarea class="form-control" id="comment" name="comment" rows="4" placeholder="Share your thoughts about this cake..." required></textarea>
                        </div>
                        <input type="hidden" id="cake_id" name="cake_id">
                        <button type="submit" class="btn btn-success w-100">
                            <i class="fas fa-paper-plane me-1"></i> Submit Review
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/YOUR-KIT-ID.js" crossorigin="anonymous"></script>

    <script>
        // Current cart state
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let selectedToppings = [];
        let currentCakeData = {};
        
        // Update cart count badge
        function updateCartCount() {
            const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
            document.getElementById('cartCount').textContent = cartCount;
        }
        
        // Initialize page
        document.addEventListener('DOMContentLoaded', function() {
            updateCartCount();
            setupFilterListeners();
        });
        
        // Set up cake id for review form
        function setCakeId(cakeId) {
            document.getElementById("cake_id").value = cakeId;
            
            // Reset star rating
            document.querySelectorAll(".star-rating .star").forEach(star => {
                star.classList.remove("selected");
                star.innerHTML = '<i class="far fa-star"></i>';
            });
            document.getElementById("rating").value = "";
            document.getElementById("comment").value = "";
        }
        
        // Star rating selection
        document.querySelectorAll(".star-rating .star").forEach(star => {
            star.addEventListener("click", function() {
                const rating = this.getAttribute("data-value");
                document.getElementById("rating").value = rating;
                
                document.querySelectorAll(".star-rating .star").forEach(s => {
                    const starValue = s.getAttribute("data-value");
                    s.classList.remove("selected");
                    
                    if (starValue <= rating) {
                        s.classList.add("selected");
                        s.innerHTML = '<i class="fas fa-star"></i>';
                    } else {
                        s.innerHTML = '<i class="far fa-star"></i>';
                    }
                });
            });
        });
        
        // Submit review form
        document.getElementById("reviewForm").addEventListener("submit", function(event) {
            event.preventDefault();
            
            if (!document.getElementById("rating").value) {
                alert("Please select a rating before submitting.");
                return;
            }
            
            const formData = new FormData(this);
            
            fetch("submit_review.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    alert("Thank you! Your review has been submitted successfully.");
                    const modal = bootstrap.Modal.getInstance(document.getElementById('reviewModal'));
                    modal.hide();
                    location.reload(); // Reload to show updated ratings
                } else {
                    alert("Error: " + data.message);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("An error occurred while submitting your review. Please try again.");
            });
        });
        
        // Fetch and display reviews
        function fetchReviews(cakeId) {
            const reviewsContainer = document.getElementById("reviewsContainer");
            const reviewStats = document.getElementById("reviewStats");
            
            reviewsContainer.innerHTML = '<div class="loader"></div>';
            reviewStats.classList.add('d-none');
            
            fetch("fetch_reviews.php?cake_id=" + cakeId)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        // Calculate stats
                        const totalReviews = data.length;
                        const avgRating = data.reduce((sum, review) => sum + parseFloat(review.rating), 0) / totalReviews;
                        
                        // Update stats display
                        document.getElementById("avgRatingDisplay").textContent = avgRating.toFixed(1);
                        document.getElementById("totalReviewsDisplay").textContent = `Based on ${totalReviews} reviews`;
                        reviewStats.classList.remove('d-none');
                        
                        // Generate reviews HTML
                        let reviewsHTML = '';
                        data.forEach(review => {
                            reviewsHTML += `
                                <div class="review-card">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <h6 class="review-author mb-0">${review.username || 'Anonymous'}</h6>
                                        <div class="text-warning">
                                            ${"★".repeat(review.rating)}${"☆".repeat(5 - review.rating)}
                                        </div>
                                    </div>
                                    <p class="review-text mb-1">${review.comment}</p>
                                    <small class="text-muted">${new Date(review.created_at).toLocaleDateString()}</small>
                                </div>
                            `;
                        });
                        reviewsContainer.innerHTML = reviewsHTML;
                    } else {
                        reviewsContainer.innerHTML = `
                            <div class="text-center py-4">
                                <i class="far fa-comment-dots fa-3x text-muted mb-3"></i>
                                <p>No reviews yet. Be the first to share your experience!</p>
                                <button class="btn btn-outline-primary mt-2" data-bs-toggle="modal" data-bs-target="#reviewModal" 
                                        onclick="setCakeId(${cakeId})" data-bs-dismiss="modal">
                                    Write a Review
                                </button>
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    reviewsContainer.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            Failed to load reviews. Please try again.
                        </div>
                    `;
                });
        }


        function loadToppings(cakeId) {
        fetch(`get_stuffing.php?cake_id=${cakeId}`)
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById("toppingsContainer");
                container.innerHTML = ""; // Clear previous toppings

                if (data.error) {
                    container.innerHTML = `<p class="text-danger">${data.error}</p>`;
                    return;
                }

                data.forEach(stuffing => {
                    const button = document.createElement("button");
                    button.type = "button";
                    button.className = "btn btn-outline-primary topping-option";
                    button.setAttribute("data-price", stuffing.stuffing_price);
                    button.onclick = function () { toggleTopping(this); };
                    button.innerHTML = `${stuffing.stuffing_name} (+₹${parseFloat(stuffing.stuffing_price).toFixed(2)})`;

                    container.appendChild(button);
                });
            })
            .catch(error => {
                console.error("Error fetching toppings:", error);
            });
    }

    function toggleTopping(button) {
        button.classList.toggle("btn-primary");
        button.classList.toggle("btn-outline-primary");
    }

    document.getElementById("cartModal").addEventListener("shown.bs.modal", function (event) {
    const cakeId = document.getElementById("cakeId").value; // Get cake ID from hidden input
    if (cakeId) {
        loadToppings(cakeId);
    }
});

        // JavaScript function to prepare the cart modal with cake details
function prepareCartModal(id, name, price, image) {
    // Set the cake details in the modal
    document.getElementById('cakeId').value = id;
    document.getElementById('cakeName').textContent = name;
    document.getElementById('cakeBasePrice').textContent = `₹${price.toFixed(2)}`;
    document.getElementById('cakePrice').value = price;
    document.getElementById('cakeImage').src = image;

document.getElementById('basePriceDisplay').textContent = `₹${price.toFixed(2)}`;
    
    // Reset form values
    document.getElementById('messageText').value = '';
    document.getElementById('specialDesign').value = '';
    document.getElementById('quantity').value = 1;
    
    // Reset toppings selection
    const toppingButtons = document.querySelectorAll('.topping-option');
    toppingButtons.forEach(button => {
        button.classList.remove('active');
    });
    
    // Update total price
    updateTotalPrice();
}

// Function to toggle topping selection
function toggleTopping(element) {
    element.classList.toggle('active');
    updateTotalPrice();
}

// Function to update quantity
function updateQuantity(change) {
    const quantityInput = document.getElementById('quantity');
    let quantity = parseInt(quantityInput.value) + change;
    
    // Ensure quantity is at least 1
    quantity = Math.max(1, quantity);
    
    quantityInput.value = quantity;
    updateTotalPrice();
}

// Function to calculate and update total price
function updateTotalPrice() {
    const basePrice = parseFloat(document.getElementById('cakePrice').value);
    const quantity = parseInt(document.getElementById('quantity').value);
    let extrasCost = 0;
    
    // Calculate message cost
    const messageText = document.getElementById('messageText').value;
    if (messageText.trim() !== '') {
        extrasCost += 3; // $3 for custom message
    }
    
    // Calculate toppings cost
    const selectedToppings = document.querySelectorAll('.topping-option.active');
    selectedToppings.forEach(topping => {
        extrasCost += parseFloat(topping.getAttribute('data-price'));
    });
    
    // Calculate total
    const totalExtras = extrasCost;
    const totalBase = basePrice * quantity;
    const totalPrice = totalBase + totalExtras;
    
    // Update display
    document.getElementById('extrasCostDisplay').textContent = `₹${totalExtras.toFixed(2)}`;
    document.getElementById('basePriceDisplay').textContent = `₹${totalBase.toFixed(2)}`;
    document.getElementById('totalPrice').textContent = `₹${totalPrice.toFixed(2)}`;
}

// Function to add item to cart
function addToCart() {
    // Get all form data
    const cakeId = document.getElementById('cakeId').value;
    const quantity = document.getElementById('quantity').value;
    const messageText = document.getElementById('messageText').value;
    const specialDesign = document.getElementById('specialDesign').value;
    
    // Get selected toppings
    const selectedToppings = [];
    document.querySelectorAll('.topping-option.active').forEach(topping => {
        selectedToppings.push(topping.textContent.trim().split('(')[0].trim());
    });
    
    // Create form data object
    const formData = new FormData();
    formData.append('cake_id', cakeId);
    formData.append('quantity', quantity);
    formData.append('message_text', messageText);
    formData.append('special_design', specialDesign);
    formData.append('toppings', JSON.stringify(selectedToppings));
    formData.append('action', 'add_to_cart');
    
    // Send AJAX request to server
    fetch('cart_handler.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('cartModal'));
            modal.hide();
            
            // Show success message
            showNotification('Item added to cart successfully!', 'success');
             // Reload page after a short delay
             setTimeout(() => {
                location.reload();
            }, 1); // Reload after 1 second to show notification before reloading

            // Update cart count in navbar if exists
            if (document.getElementById('cartCount')) {
                document.getElementById('cartCount').textContent = data.cart_count;
            }
        } else {
            showNotification('Error: ' + data.message, 'error');
        }

    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred. Please try again.', 'error');
    });
}

// Helper function to show notifications
function showNotification(message, type) {
    const toastContainer = document.getElementById('toastContainer') || createToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'} me-2"></i>
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    toastContainer.appendChild(toast);
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', function () {
        toast.remove();
    });
}

// Create toast container if it doesn't exist
function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
    document.body.appendChild(container);
    return container;
}
        
</Script>
<footer class="bg-dark text-light mt-5 py-4">
    <div class="container text-center">
        <b><p>DM us on EMAIL for personal customized orders🎂</p>
        <p>Made with ❤️ for cake lovers everywhere. </p>

        <p><i class="fas fa-envelope"></i>  Email - bakewithus@gmail.com<p>
        <p>© 2024 Bake With Us. All rights reserved.</p></b>
    </div>
</footer>
    </body>
    </html>