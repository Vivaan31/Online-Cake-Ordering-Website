<?php
session_start();
include "config.php"; // Database connection

// Set correct timezone
date_default_timezone_set('UTC');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Validate token
    $stmt = $conn->prepare("SELECT email, expires_at FROM password_reset_tokens WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($email, $expires_at);
    $stmt->fetch();

    if ($stmt->num_rows > 0) {
        // Check if token is expired
        $current_time = date("Y-m-d H:i:s");
        if ($current_time > $expires_at) {
            $_SESSION['error'] = "Your reset link has expired. Please request a new one.";
            header("Location: forgot-password.php");
            exit();
        }

        // Update the password
        $stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE email = ?");
        $stmt->bind_param("ss", $new_password, $email);
        $stmt->execute();

        // Delete token
        $stmt = $conn->prepare("DELETE FROM password_reset_tokens WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $_SESSION['success'] = "Password reset successfully. You can now log in.";
        header("Location: login.php");
    } else {
        $_SESSION['error'] = "Invalid or expired token.";
        header("Location: reset-password.php?token=" . $token);
    }
    exit();
}

// Get token from URL
$token = $_GET['token'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Reset Password</h2>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form action="reset-password.php" method="POST">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
        <input type="password" class="form-control" name="password" placeholder="Enter new password" required>
        <button type="submit" class="btn btn-primary mt-2">Reset Password</button>
    </form>
</div>
</body>
</html>
